// Mesh Diagram Visualization with D3.js
// Color-coded network diagram: Green (<80%), Yellow (80-90%), Red (>90%)

let meshSvg = null;
let simulation = null;
let nodes = [];
let links = [];
let centerX = 400;
let centerY = 300;

// Initialize mesh diagram
function initializeMeshDiagram() {
    const container = document.getElementById('meshDiagram');
    if (!container) return;

    // Set minimum height for the container
    container.style.minHeight = '600px';

    const width = container.clientWidth || 800;
    const height = 600;

    // Update center coordinates based on actual size
    centerX = width / 2;
    centerY = height / 2;

    // Clear any existing SVG to prevent duplicates
    d3.select('#meshDiagram').selectAll('*').remove();

    // Create SVG
    meshSvg = d3.select('#meshDiagram')
        .append('svg')
        .attr('width', '100%')
        .attr('height', '100%')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .attr('preserveAspectRatio', 'xMidYMid meet')
        .style('min-height', '600px');

    // Add zoom behavior
    const zoom = d3.zoom()
        .scaleExtent([0.5, 3])
        .on('zoom', (event) => {
            meshSvg.select('g').attr('transform', event.transform);
        });

    meshSvg.call(zoom);

    // Create main group
    const g = meshSvg.append('g');

    // Create arrow markers for links
    meshSvg.append('defs').selectAll('marker')
        .data(['green', 'yellow', 'red'])
        .enter().append('marker')
        .attr('id', d => `arrow-${d}`)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 20)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', d => {
            if (d === 'green') return '#00ff88';
            if (d === 'yellow') return '#ffb800';
            return '#ff3366';
        });

    // Initialize with sample data
    generateSampleMeshData();
    updateMeshDiagram();
}

// Generate sample mesh data
function generateSampleMeshData() {
    // Central gateway node
    nodes = [
        { id: 'gateway', name: 'Payment Gateway', type: 'gateway', x: centerX, y: centerY, load: 65 }
    ];

    // Issuer nodes
    for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * 2 * Math.PI;
        const radius = 180;
        nodes.push({
            id: `issuer-${i}`,
            name: `Bank-${String.fromCharCode(65 + i)}`,
            type: 'issuer',
            x: centerX + radius * Math.cos(angle),
            y: centerY + radius * Math.sin(angle),
            load: Math.random() * 100
        });
    }

    // Processor nodes
    for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * 2 * Math.PI;
        const radius = 280;
        nodes.push({
            id: `processor-${i}`,
            name: `Processor-${i + 1}`,
            type: 'processor',
            x: centerX + radius * Math.cos(angle),
            y: centerY + radius * Math.sin(angle),
            load: Math.random() * 100
        });
    }

    // Create links
    links = [];

    // Gateway to issuers
    for (let i = 0; i < 8; i++) {
        links.push({
            source: 'gateway',
            target: `issuer-${i}`,
            load: Math.random() * 100
        });
    }

    // Issuers to processors
    for (let i = 0; i < 8; i++) {
        const processorIndex = Math.floor(Math.random() * 12);
        links.push({
            source: `issuer-${i}`,
            target: `processor-${processorIndex}`,
            load: Math.random() * 100
        });
    }
}

// Update mesh diagram with real data
function updateMeshDiagram(data) {
    if (!meshSvg) {
        initializeMeshDiagram();
        return;
    }

    // Update with real data if available
    if (data && data.route_metrics) {
        updateNodesFromMetrics(data.route_metrics);
    }

    renderMeshDiagram();
}

function updateNodesFromMetrics(routeMetrics) {
    // Update node loads based on real metrics
    Object.entries(routeMetrics).forEach(([routeId, metrics]) => {
        const node = nodes.find(n => n.id === routeId);
        if (node) {
            node.load = metrics.load_percentage || 0;
        }
    });

    // Update link loads
    links.forEach(link => {
        link.load = Math.random() * 100; // In production, use real data
    });
}

function renderMeshDiagram() {
    if (!meshSvg) return;

    const g = meshSvg.select('g');

    // Stop previous simulation if it exists
    if (simulation) {
        simulation.stop();
    }

    // Clear all existing elements
    g.selectAll('.link').remove();
    g.selectAll('.node').remove();
    g.selectAll('.particle').remove();

    // Force simulation
    simulation = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(d => d.id).distance(100))
        .force('charge', d3.forceManyBody().strength(-300))
        .force('center', d3.forceCenter(centerX, centerY))
        .force('collision', d3.forceCollide().radius(30));

    // Draw links
    const link = g.selectAll('.link')
        .data(links)
        .join('line')
        .attr('class', 'link')
        .attr('stroke', d => getColorByLoad(d.load))
        .attr('stroke-width', d => Math.max(1, d.load / 20))
        .attr('stroke-opacity', 0.6)
        .attr('marker-end', d => `url(#arrow-${getColorNameByLoad(d.load)})`);

    // Draw nodes
    const node = g.selectAll('.node')
        .data(nodes)
        .join('g')
        .attr('class', 'node')
        .call(drag(simulation));

    // Node circles
    node.append('circle')
        .attr('r', d => {
            if (d.type === 'gateway') return 20;
            if (d.type === 'issuer') return 15;
            return 10;
        })
        .attr('fill', d => getColorByLoad(d.load))
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .style('filter', d => `drop-shadow(0 0 ${d.load > 80 ? 10 : 5}px ${getColorByLoad(d.load)})`);

    // Node labels
    node.append('text')
        .text(d => d.name)
        .attr('x', 0)
        .attr('y', d => d.type === 'gateway' ? -25 : -20)
        .attr('text-anchor', 'middle')
        .attr('fill', '#b8c5d6')
        .attr('font-size', '10px')
        .attr('font-weight', 'bold');

    // Load percentage labels
    node.append('text')
        .text(d => `${Math.round(d.load)}%`)
        .attr('x', 0)
        .attr('y', 5)
        .attr('text-anchor', 'middle')
        .attr('fill', '#fff')
        .attr('font-size', '9px');

    // Tooltips
    node.append('title')
        .text(d => `${d.name}\nLoad: ${Math.round(d.load)}%\nStatus: ${getStatusByLoad(d.load)}`);

    // Update positions on tick
    simulation.on('tick', () => {
        link
            .attr('x1', d => d.source.x)
            .attr('y1', d => d.source.y)
            .attr('x2', d => d.target.x)
            .attr('y2', d => d.target.y);

        node.attr('transform', d => `translate(${d.x},${d.y})`);
    });

    // Animate links
    animateLinks();
}

// Drag behavior
function drag(simulation) {
    function dragstarted(event) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
    }

    function dragged(event) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
    }

    function dragended(event) {
        if (!event.active) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
    }

    return d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended);
}

// Animate transaction flow on links
function animateLinks() {
    const g = meshSvg.select('g');

    // Remove existing particles
    g.selectAll('.particle').remove();

    // Add animated particles
    links.forEach((link, i) => {
        setTimeout(() => {
            const particle = g.append('circle')
                .attr('class', 'particle')
                .attr('r', 3)
                .attr('fill', getColorByLoad(link.load))
                .attr('cx', link.source.x)
                .attr('cy', link.source.y);

            particle.transition()
                .duration(2000)
                .ease(d3.easeLinear)
                .attr('cx', link.target.x)
                .attr('cy', link.target.y)
                .on('end', function () {
                    d3.select(this).remove();
                });
        }, i * 100);
    });

    // Repeat animation
    setTimeout(animateLinks, 3000);
}

// Color helpers
function getColorByLoad(load) {
    if (load < 80) return '#00ff88'; // Green
    if (load < 90) return '#ffb800'; // Yellow
    return '#ff3366'; // Red
}

function getColorNameByLoad(load) {
    if (load < 80) return 'green';
    if (load < 90) return 'yellow';
    return 'red';
}

function getStatusByLoad(load) {
    if (load < 80) return 'Healthy';
    if (load < 90) return 'Warning';
    return 'Critical';
}

// Initialize on load
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(initializeMeshDiagram, 500);

    // Update mesh diagram periodically
    setInterval(() => {
        // Simulate load changes
        nodes.forEach(node => {
            node.load = Math.max(0, Math.min(100, node.load + (Math.random() - 0.5) * 10));
        });
        links.forEach(link => {
            link.load = Math.max(0, Math.min(100, link.load + (Math.random() - 0.5) * 10));
        });
        renderMeshDiagram();
    }, 5000);
});

// Handle window resize
window.addEventListener('resize', () => {
    const container = document.getElementById('meshDiagram');
    if (container && meshSvg) {
        const width = container.clientWidth;
        const height = 600;
        centerX = width / 2;
        centerY = height / 2;
        meshSvg.attr('viewBox', `0 0 ${width} ${height}`);
    }
});
