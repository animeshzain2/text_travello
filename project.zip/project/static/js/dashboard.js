// Dashboard JavaScript - Real-time Updates and Interactions

let ws = null;
let latencyChart = null;
let successChart = null;

// Initialize dashboard on load
document.addEventListener('DOMContentLoaded', function () {
    console.log('Dashboard initializing...');
    initializeWebSocket();
    initializeCharts();
    loadAgentStatus();
    loadMetrics();
    loadAlerts();

    // Refresh every 5 seconds
    setInterval(refreshDashboard, 5000);
});

// WebSocket Connection
function initializeWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/dashboard`;

    ws = new WebSocket(wsUrl);

    ws.onopen = function () {
        console.log('WebSocket connected');
        updateSystemStatus(true);
    };

    ws.onmessage = function (event) {
        const data = JSON.parse(event.data);
        handleWebSocketMessage(data);
    };

    ws.onerror = function (error) {
        console.error('WebSocket error:', error);
        updateSystemStatus(false);
    };

    ws.onclose = function () {
        console.log('WebSocket disconnected');
        updateSystemStatus(false);
        // Reconnect after 5 seconds
        setTimeout(initializeWebSocket, 5000);
    };
}

function handleWebSocketMessage(data) {
    if (data.type === 'metrics_update') {
        updateMetrics(data.metrics);
        updateAgentStates(data.agent_states);
    }
}

function updateSystemStatus(isOnline) {
    const statusIndicator = document.getElementById('systemStatus');
    const statusText = document.getElementById('systemStatusText');

    if (isOnline) {
        statusIndicator.classList.add('active');
        statusText.textContent = 'System: Operational';
    } else {
        statusIndicator.classList.remove('active');
        statusText.textContent = 'System: Offline';
    }
}

// Load Agent Status
async function loadAgentStatus() {
    try {
        const response = await fetch('/api/agents/status');
        const data = await response.json();

        displayAgentCards(data.agents);
    } catch (error) {
        console.error('Error loading agent status:', error);
    }
}

function displayAgentCards(agents) {
    const panel = document.getElementById('agentStatusPanel');
    panel.innerHTML = '';

    const agentNames = {
        'performance_monitor': 'Performance Monitor',
        'predictive_analytics': 'Predictive Analytics',
        'decision_optimizer': 'Decision & Optimization',
        'config_manager': 'Configuration Manager',
        'alerting': 'Alerting & Reporting'
    };

    const agentIcons = {
        'performance_monitor': 'fa-chart-line',
        'predictive_analytics': 'fa-brain',
        'decision_optimizer': 'fa-cogs',
        'config_manager': 'fa-sliders-h',
        'alerting': 'fa-bell'
    };

    for (const [key, agent] of Object.entries(agents)) {
        const col = document.createElement('div');
        col.className = 'col-md-6 col-lg-4 col-xl mb-3';

        const statusClass = agent.health === 'healthy' ? 'active' :
            agent.health === 'degraded' ? 'warning' : 'error';

        col.innerHTML = `
            <a href="/agent_${key}.html" style="text-decoration: none; color: inherit;">
                <div class="agent-card" style="cursor: pointer;">
                    <div class="agent-header">
                        <span class="agent-status-dot ${statusClass}"></span>
                        <i class="fas ${agentIcons[key] || 'fa-robot'}"></i>
                        <span class="agent-name">${agentNames[key] || agent.agent_name}</span>
                    </div>
                    <div class="agent-metrics">
                        <div class="agent-metric">
                            <div class="agent-metric-label">Status</div>
                            <div class="agent-metric-value">${agent.status}</div>
                        </div>
                        <div class="agent-metric">
                            <div class="agent-metric-label">Tasks</div>
                            <div class="agent-metric-value">${agent.tasks_completed}</div>
                        </div>
                        <div class="agent-metric">
                            <div class="agent-metric-label">Uptime</div>
                            <div class="agent-metric-value">${agent.uptime_percentage.toFixed(1)}%</div>
                        </div>
                        <div class="agent-metric">
                            <div class="agent-metric-label">Health</div>
                            <div class="agent-metric-value">${agent.health}</div>
                        </div>
                    </div>
                </div>
            </a>
        `;

        panel.appendChild(col);
    }
}

function updateAgentStates(agentStates) {
    if (agentStates && agentStates.agents) {
        displayAgentCards(agentStates.agents);
    }
}

// Load Metrics
async function loadMetrics() {
    try {
        const response = await fetch('/api/metrics/current');
        const data = await response.json();

        updateMetrics(data);
        updateMeshDiagram(data);
    } catch (error) {
        console.error('Error loading metrics:', error);
    }
}

function updateMetrics(data) {
    const routeMetrics = data.route_metrics || {};
    const routes = Object.values(routeMetrics);

    // Calculate totals
    const totalTransactions = routes.reduce((sum, r) => sum + (r.total_transactions || 0), 0);
    const activeRoutes = routes.length;
    const avgLatency = routes.length > 0
        ? routes.reduce((sum, r) => sum + (r.avg_latency_ms || 0), 0) / routes.length
        : 0;
    const avgSuccessRate = routes.length > 0
        ? routes.reduce((sum, r) => sum + (r.success_rate || 0), 0) / routes.length
        : 0;

    // Update KPI cards
    document.getElementById('totalTransactions').textContent = totalTransactions.toLocaleString();
    document.getElementById('activeRoutes').textContent = activeRoutes;
    document.getElementById('avgLatency').textContent = Math.round(avgLatency) + 'ms';
    document.getElementById('successRate').textContent = avgSuccessRate.toFixed(1) + '%';

    // Update charts
    updateLatencyChart(routes);
    updateSuccessChart(avgSuccessRate);
}

// Load Alerts
async function loadAlerts() {
    try {
        const response = await fetch('/api/alerts/list');
        const data = await response.json();

        displayAlerts(data.alerts || []);
    } catch (error) {
        console.error('Error loading alerts:', error);
    }
}

function displayAlerts(alerts) {
    const alertCenter = document.getElementById('alertCenter');

    if (alerts.length === 0) {
        alertCenter.innerHTML = '<p class="text-muted text-center">No active alerts</p>';
        return;
    }

    alertCenter.innerHTML = '';

    alerts.forEach(alert => {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert-item ${alert.severity}`;

        alertDiv.innerHTML = `
            <div class="alert-header">
                <span class="alert-severity">${alert.severity}</span>
                <span class="alert-time">${formatTime(alert.timestamp)}</span>
            </div>
            <div class="alert-message">${alert.message}</div>
            <div class="alert-actions">
                <button class="btn btn-sm btn-outline-primary" onclick="viewAlertDetails('${alert.alert_id}')">
                    Details
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="resolveAlert('${alert.alert_id}')">
                    Resolve
                </button>
            </div>
        `;

        alertCenter.appendChild(alertDiv);
    });
}

// Initialize Charts
function initializeCharts() {
    // Latency Chart
    const latencyCtx = document.getElementById('latencyChart').getContext('2d');
    latencyChart = new Chart(latencyCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Average Latency (ms)',
                data: [],
                borderColor: '#00f5ff',
                backgroundColor: 'rgba(0, 245, 255, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#b8c5d6' }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                },
                x: {
                    ticks: { color: '#b8c5d6' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });

    // Success Chart
    const successCtx = document.getElementById('successChart').getContext('2d');
    successChart = new Chart(successCtx, {
        type: 'doughnut',
        data: {
            labels: ['Success', 'Failed'],
            datasets: [{
                data: [95, 5],
                backgroundColor: ['#00ff88', '#ff3366'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#b8c5d6' }
                }
            }
        }
    });
}

function updateLatencyChart(routes) {
    if (!latencyChart || routes.length === 0) return;

    const labels = routes.map(r => r.route_id);
    const data = routes.map(r => r.avg_latency_ms || 0);

    latencyChart.data.labels = labels.slice(0, 10); // Show first 10
    latencyChart.data.datasets[0].data = data.slice(0, 10);
    latencyChart.update();
}

function updateSuccessChart(successRate) {
    if (!successChart) return;

    const failureRate = 100 - successRate;
    successChart.data.datasets[0].data = [successRate, failureRate];
    successChart.update();
}

// Actions
async function refreshDashboard() {
    await loadAgentStatus();
    await loadMetrics();
    await loadAlerts();
}

async function simulateTransactions() {
    try {
        const response = await fetch('/api/transactions/simulate?count=100', {
            method: 'POST'
        });
        const data = await response.json();

        console.log('Simulated transactions:', data);

        // Refresh dashboard after simulation
        setTimeout(refreshDashboard, 2000);
    } catch (error) {
        console.error('Error simulating transactions:', error);
    }
}

async function resolveAlert(alertId) {
    try {
        const response = await fetch(`/api/alerts/resolve/${alertId}`, {
            method: 'POST'
        });
        const data = await response.json();

        console.log('Alert resolved:', data);
        await loadAlerts();
    } catch (error) {
        console.error('Error resolving alert:', error);
    }
}

function viewAlertDetails(alertId) {
    console.log('View alert details:', alertId);
    // Implement modal or detail view
}

// Utility Functions
function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000); // seconds

    if (diff < 60) return `${diff}s ago`;
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return date.toLocaleDateString();
}

// Show Agent Details Modal
function showAgentDetails(agentKey, agentDataStr) {
    // Parse agent data if it's a string
    const agentData = typeof agentDataStr === 'string' ? JSON.parse(agentDataStr) : agentDataStr;

    const agentNames = {
        'performance_monitor': 'Performance Monitor Agent',
        'predictive_analytics': 'Predictive Analytics Agent',
        'decision_optimizer': 'Decision & Optimization Agent',
        'config_manager': 'Configuration Manager Agent',
        'alerting': 'Alerting & Reporting Agent'
    };

    const agentDescriptions = {
        'performance_monitor': {
            description: 'Monitors real-time transaction performance and tracks metrics across routes, issuers, and processors.',
            capabilities: [
                'Track latency per route/issuer/processor',
                'Calculate success and decline rates',
                'Monitor load distribution',
                'Detect performance degradation',
                'Generate color-coded status indicators'
            ],
            metrics: ['Average Latency (ms)', 'P95/P99 Latency', 'Success Rate (%)', 'Load Percentage']
        },
        'predictive_analytics': {
            description: 'Uses machine learning models to predict future performance trends and detect anomalies.',
            capabilities: [
                'Predict future latency trends',
                'Forecast decline probability',
                'Detect anomalies in transaction patterns',
                'Provide confidence scores (94.2% accuracy)',
                'Time-series forecasting'
            ],
            metrics: ['Latency Predictor (LSTM/Prophet)', 'Decline Predictor (XGBoost)', 'Anomaly Detector (Isolation Forest)']
        },
        'decision_optimizer': {
            description: 'Makes intelligent routing decisions using multi-criteria optimization algorithms.',
            capabilities: [
                'Multi-criteria optimization',
                'Load balancing across routes',
                'Route recommendation',
                'Alternative evaluation',
                'Cost-benefit analysis'
            ],
            metrics: ['Latency Minimization', 'Success Rate Maximization', 'Cost Optimization', 'Load Distribution']
        },
        'config_manager': {
            description: 'Manages routing configurations with version control, approval workflows, and rollback capabilities.',
            capabilities: [
                'Version-controlled routing configs',
                'Approval workflow for critical changes',
                'Rollback capabilities',
                'Configuration validation',
                'Change impact analysis'
            ],
            metrics: ['Config Version', 'Pending Changes', 'Last Update Time', 'Auto-update Status']
        },
        'alerting': {
            description: 'Generates real-time alerts, monitors SLA compliance, and creates performance reports.',
            capabilities: [
                'Generate severity-based alerts',
                'SLA compliance monitoring',
                'Performance reporting',
                'Notification distribution',
                'Alert categorization (Critical/Warning/Info/Success)'
            ],
            metrics: ['Active Alerts', 'Reports Generated', 'SLA Compliance %', 'Alert Response Time']
        }
    };

    const agentInfo = agentDescriptions[agentKey];
    const agentName = agentNames[agentKey];

    // Update modal title
    document.getElementById('modalAgentName').textContent = agentName;

    // Build modal content
    const modalBody = document.getElementById('agentModalBody');
    modalBody.innerHTML = `
        <div class="agent-detail-section">
            <h6><i class="fas fa-info-circle"></i> Description</h6>
            <p>${agentInfo.description}</p>
        </div>
        
        <div class="agent-detail-section">
            <h6><i class="fas fa-chart-bar"></i> Current Status</h6>
            <div class="agent-detail-grid">
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Agent ID</div>
                    <div class="agent-detail-value">${agentData.agent_id}</div>
                </div>
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Status</div>
                    <div class="agent-detail-value">${agentData.status}</div>
                </div>
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Health</div>
                    <div class="agent-detail-value">${agentData.health}</div>
                </div>
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Tasks Completed</div>
                    <div class="agent-detail-value">${agentData.tasks_completed}</div>
                </div>
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Uptime</div>
                    <div class="agent-detail-value">${agentData.uptime_percentage.toFixed(2)}%</div>
                </div>
                <div class="agent-detail-item">
                    <div class="agent-detail-label">Last Activity</div>
                    <div class="agent-detail-value">${new Date(agentData.last_activity).toLocaleTimeString()}</div>
                </div>
            </div>
        </div>
        
        <div class="agent-detail-section">
            <h6><i class="fas fa-cogs"></i> Capabilities</h6>
            <ul class="agent-capability-list">
                ${agentInfo.capabilities.map(cap => `<li><i class="fas fa-check-circle"></i> ${cap}</li>`).join('')}
            </ul>
        </div>
        
        <div class="agent-detail-section">
            <h6><i class="fas fa-tachometer-alt"></i> Key Metrics</h6>
            <ul class="agent-capability-list">
                ${agentInfo.metrics.map(metric => `<li><i class="fas fa-chart-line"></i> ${metric}</li>`).join('')}
            </ul>
        </div>
    `;

    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('agentModal'));
    modal.show();
}
