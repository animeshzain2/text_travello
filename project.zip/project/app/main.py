"""
Main FastAPI Application - Intelligent Routing Optimization Agent
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging
import asyncio
import json
from typing import List
from datetime import datetime

from config.settings import settings
from app.database.connection import init_db, get_db
from app.agents.mcp_orchestrator import orchestrator
from app.services.data_generator import data_generator
from app.services.llm_service import llm_service

# Configure logging
logging.basicConfig(
    level=settings.LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting message: {str(e)}")


manager = ConnectionManager()


# Lifespan context manager
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting Intelligent Routing Optimization Agent...")
    
    # Initialize database
    init_db()
    logger.info("Database initialized")
    
    # Start all agents
    await orchestrator.start_all_agents()
    logger.info("All agents started")
    
    # Start background tasks
    asyncio.create_task(transaction_simulator())
    asyncio.create_task(metrics_broadcaster())
    
    yield
    
    # Shutdown
    logger.info("Shutting down...")
    await orchestrator.stop_all_agents()
    logger.info("All agents stopped")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Configure templates
templates = Jinja2Templates(directory="templates")


# HTML Routes
@app.get("/")
async def read_root(request: Request):
    """Serve the main dashboard"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/agent_performance_monitor.html")
async def agent_performance_monitor(request: Request):
    """Serve Performance Monitor Agent detail page"""
    return templates.TemplateResponse("agent_performance_monitor.html", {"request": request})

@app.get("/agent_predictive_analytics.html")
async def agent_predictive_analytics(request: Request):
    """Serve Predictive Analytics Agent detail page"""
    return templates.TemplateResponse("agent_predictive_analytics.html", {"request": request})

@app.get("/agent_decision_optimizer.html")
async def agent_decision_optimizer(request: Request):
    """Serve Decision Optimizer Agent detail page"""
    return templates.TemplateResponse("agent_decision_optimizer.html", {"request": request})

@app.get("/agent_config_manager.html")
async def agent_config_manager(request: Request):
    """Serve Config Manager Agent detail page"""
    return templates.TemplateResponse("agent_config_manager.html", {"request": request})

@app.get("/agent_alerting.html")
async def agent_alerting(request: Request):
    """Serve Alerting Agent detail page"""
    return templates.TemplateResponse("agent_alerting.html", {"request": request})


# API Endpoints
@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/agents/status")
async def get_agents_status():
    """Get status of all AI agents"""
    states = await orchestrator.get_all_agent_states()
    return states


@app.get("/api/metrics/current")
async def get_current_metrics():
    """Get current performance metrics"""
    perf_agent = orchestrator.get_agent("performance_monitor")
    metrics = await perf_agent.execute_task({"type": "get_metrics"})
    return metrics


@app.get("/api/routes/performance")
async def get_route_performance():
    """Get performance metrics for all routes"""
    perf_agent = orchestrator.get_agent("performance_monitor")
    metrics = await perf_agent.execute_task({"type": "get_metrics"})
    
    route_metrics = metrics.get("route_metrics", {})
    
    # Convert to list for easier frontend consumption
    routes_list = [
        {
            "route_id": route_id,
            **route_data
        }
        for route_id, route_data in route_metrics.items()
    ]
    
    return {
        "routes": routes_list,
        "total_routes": len(routes_list),
        "timestamp": datetime.now().isoformat()
    }


@app.post("/api/routes/optimize/{route_id}")
async def optimize_route(route_id: str):
    """Trigger optimization for a specific route"""
    result = await orchestrator.optimize_routing(route_id)
    return result


@app.get("/api/alerts/list")
async def get_alerts():
    """Get all active alerts"""
    alerting_agent = orchestrator.get_agent("alerting")
    alerts = await alerting_agent.execute_task({"type": "get_alerts"})
    return alerts


@app.post("/api/alerts/resolve/{alert_id}")
async def resolve_alert(alert_id: str):
    """Resolve an alert"""
    alerting_agent = orchestrator.get_agent("alerting")
    result = await alerting_agent.execute_task({
        "type": "resolve_alert",
        "alert_id": alert_id
    })
    return result


@app.post("/api/transactions/simulate")
async def simulate_transactions(count: int = 100):
    """Simulate transaction batch"""
    transactions = data_generator.generate_batch(count=count)
    
    # Process first few through the system
    for transaction in transactions[:10]:
        await orchestrator.process_transaction(transaction)
    
    return {
        "status": "simulated",
        "count": count,
        "processed": 10,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/predictions/latency/{route_id}")
async def predict_latency(route_id: str):
    """Get latency prediction for a route"""
    pred_agent = orchestrator.get_agent("predictive_analytics")
    prediction = await pred_agent.execute_task({
        "type": "predict_latency",
        "route_id": route_id
    })
    return prediction


@app.get("/api/config/pending")
async def get_pending_changes():
    """Get pending configuration changes"""
    config_agent = orchestrator.get_agent("config_manager")
    pending = await config_agent.execute_task({"type": "get_pending"})
    return pending



@app.post("/api/llm/query")
async def llm_query(query: str):
    """Query the LLM for insights"""
    try:
        # Get current system context
        states = await orchestrator.get_all_agent_states()
        
        response = llm_service.chat_query(query, context=states)
        
        return {
            "query": query,
            "response": response,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        return {"error": str(e)}


@app.post("/api/ai/analyze-routing")
async def ai_analyze_routing(transaction_data: dict):
    """Use AI to analyze and recommend optimal routing for a transaction"""
    try:
        # Get current performance metrics
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        # Use LLM to analyze routing decision
        analysis = llm_service.analyze_routing_decision(
            transaction_data=transaction_data,
            performance_metrics={
                "available_routes": len(metrics.get("route_metrics", {})),
                "avg_latency": metrics.get("avg_latency", 150),
                "decline_rate": metrics.get("decline_rate", 3.5),
                "load_distribution": metrics.get("load_distribution", {})
            }
        )
        
        return {
            "transaction": transaction_data,
            "ai_analysis": analysis,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI routing analysis failed: {str(e)}")
        return {"error": str(e), "fallback": "Using rule-based routing"}


@app.post("/api/ai/explain-anomaly")
async def ai_explain_anomaly(anomaly_data: dict):
    """Use AI to explain detected anomalies in human-readable format"""
    try:
        explanation = llm_service.explain_anomaly(anomaly_data)
        
        return {
            "anomaly": anomaly_data,
            "ai_explanation": explanation,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI anomaly explanation failed: {str(e)}")
        return {"error": str(e)}


@app.post("/api/ai/optimization-strategy")
async def ai_optimization_strategy():
    """Generate AI-powered optimization strategy based on current system state"""
    try:
        # Get current state
        states = await orchestrator.get_all_agent_states()
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        current_state = {
            "total_routes": len(metrics.get("route_metrics", {})),
            "active_transactions": metrics.get("total_transactions", 0),
            "system_load": metrics.get("system_load", 65),
            "recent_failures": metrics.get("failed_transactions", 0)
        }
        
        historical_data = {
            "avg_latency": metrics.get("avg_latency", 150),
            "success_rate": metrics.get("success_rate", 95.4),
            "peak_load_time": "14:00-16:00"
        }
        
        strategy = llm_service.generate_optimization_strategy(
            current_state=current_state,
            historical_data=historical_data
        )
        
        return {
            "current_state": current_state,
            "ai_strategy": strategy,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI optimization strategy failed: {str(e)}")
        return {"error": str(e)}


@app.get("/api/ai/insights")
async def ai_insights():
    """Get AI-generated insights about system performance"""
    try:
        # Get system metrics
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        # Generate insights using LLM
        prompt = f"""
        Analyze this payment routing system performance and provide 3-5 key insights:
        
        Current Metrics:
        - Total Transactions: {metrics.get('total_transactions', 0)}
        - Success Rate: {metrics.get('success_rate', 0)}%
        - Average Latency: {metrics.get('avg_latency', 0)}ms
        - Active Routes: {len(metrics.get('route_metrics', {}))}
        
        Provide actionable insights in bullet points.
        """
        
        insights = llm_service.chat_query(prompt)
        
        return {
            "insights": insights,
            "metrics_snapshot": metrics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI insights generation failed: {str(e)}")
        return {"error": str(e)}


@app.post("/api/ai/analyze-routing")
async def ai_analyze_routing(transaction_data: dict):
    """Use AI to analyze and recommend optimal routing for a transaction"""
    try:
        # Get current performance metrics
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        # Use LLM to analyze routing decision
        analysis = llm_service.analyze_routing_decision(
            transaction_data=transaction_data,
            performance_metrics={
                "available_routes": len(metrics.get("route_metrics", {})),
                "avg_latency": metrics.get("avg_latency", 150),
                "decline_rate": metrics.get("decline_rate", 3.5),
                "load_distribution": metrics.get("load_distribution", {})
            }
        )
        
        return {
            "transaction": transaction_data,
            "ai_analysis": analysis,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI routing analysis failed: {str(e)}")
        return {"error": str(e), "fallback": "Using rule-based routing"}


@app.post("/api/ai/explain-anomaly")
async def ai_explain_anomaly(anomaly_data: dict):
    """Use AI to explain detected anomalies in human-readable format"""
    try:
        explanation = llm_service.explain_anomaly(anomaly_data)
        
        return {
            "anomaly": anomaly_data,
            "ai_explanation": explanation,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI anomaly explanation failed: {str(e)}")
        return {"error": str(e)}


@app.post("/api/ai/optimization-strategy")
async def ai_optimization_strategy():
    """Generate AI-powered optimization strategy based on current system state"""
    try:
        # Get current state
        states = await orchestrator.get_all_agent_states()
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        current_state = {
            "total_routes": len(metrics.get("route_metrics", {})),
            "active_transactions": metrics.get("total_transactions", 0),
            "system_load": metrics.get("system_load", 65),
            "recent_failures": metrics.get("failed_transactions", 0)
        }
        
        historical_data = {
            "avg_latency": metrics.get("avg_latency", 150),
            "success_rate": metrics.get("success_rate", 95.4),
            "peak_load_time": "14:00-16:00"
        }
        
        strategy = llm_service.generate_optimization_strategy(
            current_state=current_state,
            historical_data=historical_data
        )
        
        return {
            "current_state": current_state,
            "ai_strategy": strategy,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI optimization strategy failed: {str(e)}")
        return {"error": str(e)}


@app.get("/api/ai/insights")
async def ai_insights():
    """Get AI-generated insights about system performance"""
    try:
        # Get system metrics
        perf_agent = orchestrator.get_agent("performance_monitor")
        metrics = await perf_agent.execute_task({"type": "get_metrics"})
        
        # Generate insights using LLM
        prompt = f"""
        Analyze this payment routing system performance and provide 3-5 key insights:
        
        Current Metrics:
        - Total Transactions: {metrics.get('total_transactions', 0)}
        - Success Rate: {metrics.get('success_rate', 0)}%
        - Average Latency: {metrics.get('avg_latency', 0)}ms
        - Active Routes: {len(metrics.get('route_metrics', {}))}
        
        Provide actionable insights in bullet points.
        """
        
        insights = llm_service.chat_query(prompt)
        
        return {
            "insights": insights,
            "metrics_snapshot": metrics,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"AI insights generation failed: {str(e)}")
        return {"error": str(e)}



@app.websocket("/ws/dashboard")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time dashboard updates"""
    await manager.connect(websocket)
    
    try:
        while True:
            # Wait for messages from client
            data = await websocket.receive_text()
            
            # Echo back for now
            await websocket.send_json({
                "type": "ack",
                "message": "Message received",
                "timestamp": datetime.now().isoformat()
            })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# Background tasks
async def transaction_simulator():
    """Simulate transactions in the background"""
    await asyncio.sleep(5)  # Wait for startup
    
    while True:
        try:
            # Generate and process a transaction
            transaction = data_generator.generate_transaction()
            await orchestrator.process_transaction(transaction)
            
            # Wait before next transaction
            await asyncio.sleep(1)
            
        except Exception as e:
            logger.error(f"Transaction simulation error: {str(e)}")
            await asyncio.sleep(5)


async def metrics_broadcaster():
    """Broadcast metrics to all connected WebSocket clients"""
    await asyncio.sleep(10)  # Wait for startup
    
    while True:
        try:
            # Get current metrics
            perf_agent = orchestrator.get_agent("performance_monitor")
            metrics = await perf_agent.execute_task({"type": "get_metrics"})
            
            # Get agent states
            states = await orchestrator.get_all_agent_states()
            
            # Broadcast to all clients
            await manager.broadcast({
                "type": "metrics_update",
                "metrics": metrics,
                "agent_states": states,
                "timestamp": datetime.now().isoformat()
            })
            
            # Wait before next broadcast
            await asyncio.sleep(settings.AGENT_UPDATE_INTERVAL)
            
        except Exception as e:
            logger.error(f"Metrics broadcast error: {str(e)}")
            await asyncio.sleep(10)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG
    )
