"""
Database models for the Intelligent Routing Optimization Agent
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, JSON, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime

Base = declarative_base()


class Transaction(Base):
    """Transaction records"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    transaction_id = Column(String(100), unique=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Transaction details
    amount = Column(Float)
    currency = Column(String(3))
    card_type = Column(String(20))
    card_last_4 = Column(String(4))
    merchant_id = Column(String(50))
    merchant_category = Column(String(50))
    transaction_type = Column(String(20))
    region = Column(String(20))
    
    # Routing information
    issuer_id = Column(String(50), index=True)
    issuer_name = Column(String(100))
    processor_id = Column(String(50), index=True)
    processor_name = Column(String(100))
    route_id = Column(String(50), index=True)
    
    # Performance metrics
    latency_ms = Column(Integer)
    success = Column(Boolean)
    decline_reason = Column(String(100), nullable=True)
    is_anomaly = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class Route(Base):
    """Routing configuration"""
    __tablename__ = "routes"
    
    id = Column(Integer, primary_key=True, index=True)
    route_id = Column(String(50), unique=True, index=True)
    name = Column(String(100))
    
    # Route configuration
    issuer_id = Column(String(50))
    processor_id = Column(String(50))
    priority = Column(Integer, default=5)
    enabled = Column(Boolean, default=True)
    
    # Rules
    card_types = Column(JSON)  # List of allowed card types
    regions = Column(JSON)  # List of allowed regions
    max_amount = Column(Float)
    retry_count = Column(Integer, default=3)
    timeout_ms = Column(Integer, default=1000)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(100), default="system")
    updated_by = Column(String(100), default="system")


class PerformanceMetric(Base):
    """Performance metrics for routes, issuers, and processors"""
    __tablename__ = "performance_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Entity identification
    entity_type = Column(String(20))  # 'route', 'issuer', 'processor'
    entity_id = Column(String(50), index=True)
    
    # Metrics
    avg_latency_ms = Column(Float)
    p95_latency_ms = Column(Float, nullable=True)
    p99_latency_ms = Column(Float, nullable=True)
    success_rate = Column(Float)
    decline_rate = Column(Float)
    transactions_count = Column(Integer)
    load_percentage = Column(Float)
    
    # Status
    status = Column(String(20))  # 'healthy', 'warning', 'critical'
    color = Column(String(10))  # 'green', 'yellow', 'red'
    
    created_at = Column(DateTime, default=datetime.utcnow)


class AgentState(Base):
    """Agent status and state tracking"""
    __tablename__ = "agent_states"
    
    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(String(50), unique=True, index=True)
    agent_name = Column(String(100))
    agent_type = Column(String(50))
    
    # State
    status = Column(String(20))  # 'active', 'idle', 'error', 'stopped'
    health = Column(String(20))  # 'healthy', 'degraded', 'unhealthy'
    
    # Metrics
    uptime_percentage = Column(Float)
    tasks_completed = Column(Integer, default=0)
    tasks_failed = Column(Integer, default=0)
    last_activity = Column(DateTime, default=datetime.utcnow)
    
    # Additional data
    meta_data = Column(JSON, nullable=True)
    error_message = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Alert(Base):
    """System alerts and notifications"""
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    alert_id = Column(String(100), unique=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Alert details
    severity = Column(String(20))  # 'critical', 'warning', 'info', 'success'
    title = Column(String(200))
    message = Column(Text)
    source = Column(String(100))  # Which agent/component generated it
    
    # Related entity
    entity_type = Column(String(20), nullable=True)
    entity_id = Column(String(50), nullable=True)
    
    # Status
    acknowledged = Column(Boolean, default=False)
    resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(100), nullable=True)
    
    # Actions
    action_taken = Column(Text, nullable=True)
    meta_data = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class OptimizationLog(Base):
    """Log of optimization actions taken by the system"""
    __tablename__ = "optimization_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Optimization details
    optimization_type = Column(String(50))  # 'route_change', 'load_balance', 'failover', etc.
    trigger = Column(String(100))  # What triggered the optimization
    
    # Before state
    before_state = Column(JSON)
    
    # After state
    after_state = Column(JSON)
    
    # Results
    success = Column(Boolean)
    improvement_percentage = Column(Float, nullable=True)
    
    # Metrics
    latency_before = Column(Float, nullable=True)
    latency_after = Column(Float, nullable=True)
    success_rate_before = Column(Float, nullable=True)
    success_rate_after = Column(Float, nullable=True)
    
    # Metadata
    agent_id = Column(String(50))
    description = Column(Text)
    meta_data = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    """Audit trail for all system actions"""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Action details
    action_type = Column(String(50))  # 'config_change', 'route_update', 'manual_override', etc.
    action = Column(String(200))
    description = Column(Text)
    
    # Actor
    actor_type = Column(String(20))  # 'agent', 'user', 'system'
    actor_id = Column(String(100))
    
    # Target
    target_type = Column(String(50), nullable=True)
    target_id = Column(String(100), nullable=True)
    
    # Changes
    before_value = Column(JSON, nullable=True)
    after_value = Column(JSON, nullable=True)
    
    # Result
    success = Column(Boolean)
    error_message = Column(Text, nullable=True)
    
    # Metadata
    ip_address = Column(String(50), nullable=True)
    meta_data = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
