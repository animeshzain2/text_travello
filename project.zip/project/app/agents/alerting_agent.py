"""
Agent 5: Alerting & Reporting Agent
Generates alerts and reports on system performance
"""
from app.agents.base_agent import BaseAgent
from typing import Dict, Any, List
from datetime import datetime
import logging
import uuid

logger = logging.getLogger(__name__)


class AlertingAgent(BaseAgent):
    """
    Generates real-time alerts and performance reports
    Monitors SLA compliance and sends notifications
    """
    
    def __init__(self):
        super().__init__(
            agent_id="agent-alerting",
            agent_name="Alerting & Reporting Agent",
            agent_type="alerting"
        )
        
        self.active_alerts = []
        self.reports_generated = 0
        
        self.metadata = {
            "active_alerts": 0,
            "reports_today": 0,
            "alert_types": ["critical", "warning", "info", "success"]
        }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute alerting task"""
        try:
            task_type = task_data.get("type", "create_alert")
            
            if task_type == "create_alert":
                result = await self._create_alert(task_data)
            elif task_type == "resolve_alert":
                result = await self._resolve_alert(task_data)
            elif task_type == "generate_report":
                result = await self._generate_report(task_data)
            elif task_type == "get_alerts":
                result = await self._get_active_alerts()
            else:
                result = {"error": f"Unknown task type: {task_type}"}
            
            self.handle_success()
            return result
            
        except Exception as e:
            self.handle_error(str(e))
            return {"error": str(e)}
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze system state and generate alerts/reports"""
        try:
            metrics = data.get("metrics", {})
            thresholds = data.get("thresholds", {})
            
            # Check for alert conditions
            alerts_needed = self._check_alert_conditions(metrics, thresholds)
            
            # Generate summary report
            summary = self._generate_summary(metrics)
            
            return {
                "alerts_needed": alerts_needed,
                "summary": summary,
                "sla_status": self._check_sla_compliance(metrics),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            return {"error": str(e)}
    
    async def _create_alert(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new alert"""
        alert_id = str(uuid.uuid4())[:8]
        severity = data.get("severity", "info")
        title = data.get("title", "System Alert")
        message = data.get("message", "")
        source = data.get("source", "system")
        
        alert = {
            "alert_id": alert_id,
            "severity": severity,
            "title": title,
            "message": message,
            "source": source,
            "timestamp": datetime.now().isoformat(),
            "acknowledged": False,
            "resolved": False
        }
        
        self.active_alerts.append(alert)
        self.metadata["active_alerts"] = len(self.active_alerts)
        
        logger.info(f"Alert created: {severity} - {title}")
        
        return {
            "status": "created",
            "alert": alert
        }
    
    async def _resolve_alert(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve an existing alert"""
        alert_id = data.get("alert_id")
        
        for alert in self.active_alerts:
            if alert["alert_id"] == alert_id:
                alert["resolved"] = True
                alert["resolved_at"] = datetime.now().isoformat()
                self.active_alerts.remove(alert)
                self.metadata["active_alerts"] = len(self.active_alerts)
                
                return {
                    "status": "resolved",
                    "alert_id": alert_id
                }
        
        return {"error": "Alert not found"}
    
    async def _generate_report(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate performance report"""
        report_type = data.get("report_type", "performance")
        period = data.get("period", "24h")
        metrics = data.get("metrics", {})
        
        self.reports_generated += 1
        self.metadata["reports_today"] = self.reports_generated
        
        report = {
            "report_id": f"RPT-{self.reports_generated:04d}",
            "report_type": report_type,
            "period": period,
            "generated_at": datetime.now().isoformat(),
            "summary": self._generate_summary(metrics),
            "details": {
                "total_transactions": metrics.get("total_transactions", 0),
                "avg_latency_ms": metrics.get("avg_latency", 0),
                "success_rate": metrics.get("success_rate", 0),
                "decline_rate": metrics.get("decline_rate", 0),
                "optimizations_performed": metrics.get("optimizations", 0)
            },
            "recommendations": self._generate_recommendations(metrics)
        }
        
        return report
    
    async def _get_active_alerts(self) -> Dict[str, Any]:
        """Get all active alerts"""
        # Categorize alerts by severity
        critical = [a for a in self.active_alerts if a["severity"] == "critical"]
        warning = [a for a in self.active_alerts if a["severity"] == "warning"]
        info = [a for a in self.active_alerts if a["severity"] == "info"]
        success = [a for a in self.active_alerts if a["severity"] == "success"]
        
        return {
            "total_alerts": len(self.active_alerts),
            "critical": len(critical),
            "warning": len(warning),
            "info": len(info),
            "success": len(success),
            "alerts": self.active_alerts,
            "timestamp": datetime.now().isoformat()
        }
    
    def _check_alert_conditions(self, metrics: Dict, thresholds: Dict) -> List[Dict]:
        """Check if metrics exceed thresholds"""
        alerts = []
        
        latency = metrics.get("avg_latency", 0)
        latency_threshold = thresholds.get("latency", 200)
        if latency > latency_threshold:
            alerts.append({
                "severity": "critical" if latency > latency_threshold * 2 else "warning",
                "title": "High Latency Detected",
                "message": f"Average latency ({latency}ms) exceeds threshold ({latency_threshold}ms)",
                "source": "performance_monitor"
            })
        
        decline_rate = metrics.get("decline_rate", 0)
        decline_threshold = thresholds.get("decline_rate", 5)
        if decline_rate > decline_threshold:
            alerts.append({
                "severity": "warning",
                "title": "High Decline Rate",
                "message": f"Decline rate ({decline_rate}%) exceeds threshold ({decline_threshold}%)",
                "source": "performance_monitor"
            })
        
        load = metrics.get("load_percentage", 0)
        if load > 90:
            alerts.append({
                "severity": "critical",
                "title": "Critical Load Level",
                "message": f"System load at {load}% - immediate action required",
                "source": "performance_monitor"
            })
        elif load > 80:
            alerts.append({
                "severity": "warning",
                "title": "High Load Level",
                "message": f"System load at {load}% - monitor closely",
                "source": "performance_monitor"
            })
        
        return alerts
    
    def _generate_summary(self, metrics: Dict) -> str:
        """Generate human-readable summary"""
        latency = metrics.get("avg_latency", 0)
        success_rate = metrics.get("success_rate", 0)
        load = metrics.get("load_percentage", 0)
        
        if load > 90 or latency > 400:
            status = "System experiencing critical issues"
        elif load > 80 or latency > 200:
            status = "System performance degraded"
        else:
            status = "System operating normally"
        
        return f"{status}. Avg latency: {latency}ms, Success rate: {success_rate}%, Load: {load}%"
    
    def _check_sla_compliance(self, metrics: Dict) -> Dict[str, Any]:
        """Check SLA compliance"""
        latency = metrics.get("avg_latency", 0)
        success_rate = metrics.get("success_rate", 0)
        
        # SLA targets
        sla_latency = 200  # ms
        sla_success_rate = 99.0  # %
        
        latency_compliant = latency <= sla_latency
        success_compliant = success_rate >= sla_success_rate
        
        return {
            "overall_compliant": latency_compliant and success_compliant,
            "latency_compliant": latency_compliant,
            "success_rate_compliant": success_compliant,
            "sla_targets": {
                "latency_ms": sla_latency,
                "success_rate": sla_success_rate
            },
            "actual_values": {
                "latency_ms": latency,
                "success_rate": success_rate
            }
        }
    
    def _generate_recommendations(self, metrics: Dict) -> List[str]:
        """Generate recommendations based on metrics"""
        recommendations = []
        
        if metrics.get("avg_latency", 0) > 200:
            recommendations.append("Optimize routing to reduce latency")
        
        if metrics.get("decline_rate", 0) > 5:
            recommendations.append("Review issuer/processor performance")
        
        if metrics.get("load_percentage", 0) > 85:
            recommendations.append("Scale up capacity or enable load balancing")
        
        if not recommendations:
            recommendations.append("System performance is optimal")
        
        return recommendations
