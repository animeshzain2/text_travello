"""
Agent 3: Decision & Optimization Agent
Makes routing decisions and optimizes performance
"""
from app.agents.base_agent import BaseAgent
from typing import Dict, Any, List
from datetime import datetime
import logging
import random

logger = logging.getLogger(__name__)


class DecisionOptimizerAgent(BaseAgent):
    """
    Makes intelligent routing decisions and optimizes performance
    Uses multi-criteria optimization and LLM assistance
    """
    
    def __init__(self):
        super().__init__(
            agent_id="agent-decision-optimizer",
            agent_name="Decision & Optimization Agent",
            agent_type="optimization"
        )
        
        self.optimizations_today = 0
        self.active_optimizations = 0
        
        self.metadata = {
            "optimization_algorithms": ["multi_criteria", "load_balancing", "genetic_algorithm"],
            "optimizations_today": 0,
            "active_tasks": 0
        }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute optimization task"""
        try:
            task_type = task_data.get("type", "optimize")
            
            if task_type == "optimize_route":
                result = await self._optimize_route(task_data)
            elif task_type == "balance_load":
                result = await self._balance_load(task_data)
            elif task_type == "recommend_action":
                result = await self._recommend_action(task_data)
            elif task_type == "evaluate_alternatives":
                result = await self._evaluate_alternatives(task_data)
            else:
                result = {"error": f"Unknown task type: {task_type}"}
            
            self.optimizations_today += 1
            self.metadata["optimizations_today"] = self.optimizations_today
            self.handle_success()
            return result
            
        except Exception as e:
            self.handle_error(str(e))
            return {"error": str(e)}
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze routing options and recommend optimal strategy"""
        try:
            current_state = data.get("current_state", {})
            performance_metrics = data.get("performance_metrics", {})
            
            # Evaluate current state
            evaluation = self._evaluate_current_state(current_state, performance_metrics)
            
            # Generate optimization recommendations
            recommendations = await self._generate_recommendations(evaluation)
            
            return {
                "evaluation": evaluation,
                "recommendations": recommendations,
                "priority": self._calculate_priority(evaluation),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            return {"error": str(e)}
    
    async def _optimize_route(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize routing configuration"""
        route_id = data.get("route_id", "unknown")
        current_metrics = data.get("current_metrics", {})
        
        # Multi-criteria optimization
        optimization_result = self._multi_criteria_optimization(current_metrics)
        
        return {
            "route_id": route_id,
            "optimization_type": "route_optimization",
            "before": current_metrics,
            "after": optimization_result["optimized_metrics"],
            "improvement_percentage": optimization_result["improvement"],
            "actions_required": optimization_result["actions"],
            "timestamp": datetime.now().isoformat()
        }
    
    async def _balance_load(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Balance load across routes"""
        routes = data.get("routes", [])
        
        # Load balancing algorithm
        balanced_distribution = self._calculate_load_distribution(routes)
        
        return {
            "optimization_type": "load_balancing",
            "total_routes": len(routes),
            "balanced_distribution": balanced_distribution,
            "expected_improvement": random.randint(15, 35),
            "timestamp": datetime.now().isoformat()
        }
    
    async def _recommend_action(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recommend action based on current state"""
        issue_type = data.get("issue_type", "performance")
        severity = data.get("severity", "medium")
        
        recommendations = []
        
        if issue_type == "high_latency":
            recommendations = [
                "Switch to faster processor",
                "Enable parallel processing",
                "Increase timeout threshold"
            ]
        elif issue_type == "high_decline":
            recommendations = [
                "Route through alternative issuer",
                "Implement retry logic",
                "Review fraud rules"
            ]
        elif issue_type == "high_load":
            recommendations = [
                "Activate backup routes",
                "Distribute load evenly",
                "Scale up capacity"
            ]
        
        return {
            "issue_type": issue_type,
            "severity": severity,
            "recommendations": recommendations,
            "priority": "high" if severity == "critical" else "medium",
            "timestamp": datetime.now().isoformat()
        }
    
    async def _evaluate_alternatives(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate alternative routing options"""
        current_route = data.get("current_route", {})
        alternatives = data.get("alternatives", [])
        
        # Score each alternative
        scored_alternatives = []
        for alt in alternatives:
            score = self._calculate_route_score(alt)
            scored_alternatives.append({
                "route_id": alt.get("route_id"),
                "score": score,
                "pros": self._get_pros(alt),
                "cons": self._get_cons(alt)
            })
        
        # Sort by score
        scored_alternatives.sort(key=lambda x: x["score"], reverse=True)
        
        return {
            "current_route": current_route.get("route_id"),
            "alternatives": scored_alternatives,
            "best_alternative": scored_alternatives[0] if scored_alternatives else None,
            "timestamp": datetime.now().isoformat()
        }
    
    def _multi_criteria_optimization(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Multi-criteria optimization algorithm"""
        current_latency = metrics.get("avg_latency_ms", 150)
        current_success_rate = metrics.get("success_rate", 95)
        
        # Simulate optimization
        optimized_latency = current_latency * random.uniform(0.6, 0.85)
        optimized_success_rate = min(99.5, current_success_rate * random.uniform(1.01, 1.05))
        
        improvement = ((current_latency - optimized_latency) / current_latency) * 100
        
        return {
            "optimized_metrics": {
                "avg_latency_ms": round(optimized_latency, 1),
                "success_rate": round(optimized_success_rate, 2)
            },
            "improvement": round(improvement, 1),
            "actions": [
                "Adjust routing priority",
                "Enable caching",
                "Optimize timeout settings"
            ]
        }
    
    def _calculate_load_distribution(self, routes: List[Dict]) -> Dict[str, Any]:
        """Calculate optimal load distribution"""
        total_capacity = sum(r.get("capacity", 100) for r in routes)
        
        distribution = {}
        for route in routes:
            route_id = route.get("route_id")
            capacity = route.get("capacity", 100)
            optimal_load = (capacity / total_capacity) * 100
            distribution[route_id] = round(optimal_load, 1)
        
        return distribution
    
    def _evaluate_current_state(self, state: Dict, metrics: Dict) -> Dict[str, Any]:
        """Evaluate current system state"""
        avg_latency = metrics.get("avg_latency", 150)
        success_rate = metrics.get("success_rate", 95)
        load = state.get("load_percentage", 70)
        
        health_score = (success_rate / 100) * 0.5 + (1 - min(load / 100, 1)) * 0.3 + (1 - min(avg_latency / 500, 1)) * 0.2
        
        return {
            "health_score": round(health_score * 100, 1),
            "status": "healthy" if health_score > 0.8 else "degraded" if health_score > 0.6 else "critical",
            "bottlenecks": self._identify_bottlenecks(metrics)
        }
    
    def _identify_bottlenecks(self, metrics: Dict) -> List[str]:
        """Identify performance bottlenecks"""
        bottlenecks = []
        
        if metrics.get("avg_latency", 0) > 200:
            bottlenecks.append("High latency")
        if metrics.get("decline_rate", 0) > 5:
            bottlenecks.append("High decline rate")
        if metrics.get("load_percentage", 0) > 85:
            bottlenecks.append("High load")
        
        return bottlenecks
    
    async def _generate_recommendations(self, evaluation: Dict) -> List[Dict]:
        """Generate optimization recommendations"""
        recommendations = []
        
        if evaluation["status"] != "healthy":
            recommendations.append({
                "action": "Optimize routing configuration",
                "priority": "high",
                "expected_improvement": "30-40%"
            })
        
        if evaluation.get("bottlenecks"):
            for bottleneck in evaluation["bottlenecks"]:
                recommendations.append({
                    "action": f"Address {bottleneck}",
                    "priority": "medium",
                    "expected_improvement": "15-25%"
                })
        
        return recommendations
    
    def _calculate_priority(self, evaluation: Dict) -> str:
        """Calculate optimization priority"""
        health_score = evaluation.get("health_score", 100)
        
        if health_score < 60:
            return "critical"
        elif health_score < 80:
            return "high"
        else:
            return "normal"
    
    def _calculate_route_score(self, route: Dict) -> float:
        """Calculate route quality score"""
        latency = route.get("avg_latency_ms", 150)
        success_rate = route.get("success_rate", 95)
        load = route.get("load_percentage", 70)
        
        score = (success_rate / 100) * 0.4 + (1 - min(latency / 500, 1)) * 0.4 + (1 - min(load / 100, 1)) * 0.2
        return round(score * 100, 1)
    
    def _get_pros(self, route: Dict) -> List[str]:
        """Get route advantages"""
        pros = []
        if route.get("avg_latency_ms", 200) < 150:
            pros.append("Low latency")
        if route.get("success_rate", 90) > 95:
            pros.append("High success rate")
        if route.get("load_percentage", 100) < 70:
            pros.append("Available capacity")
        return pros
    
    def _get_cons(self, route: Dict) -> List[str]:
        """Get route disadvantages"""
        cons = []
        if route.get("avg_latency_ms", 100) > 200:
            cons.append("High latency")
        if route.get("success_rate", 100) < 95:
            cons.append("Lower success rate")
        if route.get("load_percentage", 0) > 85:
            cons.append("High load")
        return cons
