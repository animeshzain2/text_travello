"""
Base Agent class for all AI agents in the system
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime
import logging
import asyncio
from enum import Enum

logger = logging.getLogger(__name__)


class AgentStatus(Enum):
    """Agent status enumeration"""
    ACTIVE = "active"
    IDLE = "idle"
    ERROR = "error"
    STOPPED = "stopped"


class AgentHealth(Enum):
    """Agent health enumeration"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class BaseAgent(ABC):
    """
    Base class for all AI agents in the multi-agent system
    Implements common functionality and MCP protocol support
    """
    
    def __init__(self, agent_id: str, agent_name: str, agent_type: str):
        """
        Initialize base agent
        
        Args:
            agent_id: Unique agent identifier
            agent_name: Human-readable agent name
            agent_type: Type of agent
        """
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.agent_type = agent_type
        
        self.status = AgentStatus.IDLE
        self.health = AgentHealth.HEALTHY
        
        self.tasks_completed = 0
        self.tasks_failed = 0
        self.start_time = datetime.now()
        self.last_activity = datetime.now()
        
        self.metadata: Dict[str, Any] = {}
        self.error_message: Optional[str] = None
        
        self._running = False
        self._task: Optional[asyncio.Task] = None
        
        logger.info(f"Agent initialized: {self.agent_name} ({self.agent_id})")
    
    @abstractmethod
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute agent-specific task
        
        Args:
            task_data: Task parameters
            
        Returns:
            Task result
        """
        pass
    
    @abstractmethod
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze data and provide insights
        
        Args:
            data: Data to analyze
            
        Returns:
            Analysis results
        """
        pass
    
    async def start(self):
        """Start the agent"""
        if self._running:
            logger.warning(f"Agent {self.agent_name} is already running")
            return
        
        self._running = True
        self.status = AgentStatus.ACTIVE
        self._task = asyncio.create_task(self._run_loop())
        logger.info(f"Agent {self.agent_name} started")
    
    async def stop(self):
        """Stop the agent"""
        if not self._running:
            return
        
        self._running = False
        self.status = AgentStatus.STOPPED
        
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        
        logger.info(f"Agent {self.agent_name} stopped")
    
    async def _run_loop(self):
        """Main agent run loop"""
        while self._running:
            try:
                await self._tick()
                await asyncio.sleep(1)  # Adjust based on agent needs
            except Exception as e:
                logger.error(f"Error in agent {self.agent_name}: {str(e)}")
                self.handle_error(str(e))
    
    async def _tick(self):
        """
        Single iteration of agent loop
        Override in subclasses for custom behavior
        """
        self.last_activity = datetime.now()
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get current agent state
        
        Returns:
            Agent state dictionary
        """
        uptime = (datetime.now() - self.start_time).total_seconds()
        uptime_percentage = 100.0  # Simplified, could track actual downtime
        
        return {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "agent_type": self.agent_type,
            "status": self.status.value,
            "health": self.health.value,
            "uptime_seconds": uptime,
            "uptime_percentage": uptime_percentage,
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "last_activity": self.last_activity.isoformat(),
            "metadata": self.metadata,
            "error_message": self.error_message
        }
    
    def handle_error(self, error_message: str):
        """
        Handle agent error
        
        Args:
            error_message: Error description
        """
        self.tasks_failed += 1
        self.error_message = error_message
        self.health = AgentHealth.DEGRADED
        logger.error(f"Agent {self.agent_name} error: {error_message}")
    
    def handle_success(self):
        """Handle successful task completion"""
        self.tasks_completed += 1
        self.error_message = None
        self.health = AgentHealth.HEALTHY
        self.last_activity = datetime.now()
    
    def send_message(self, target_agent_id: str, message: Dict[str, Any]):
        """
        Send message to another agent (MCP protocol)
        
        Args:
            target_agent_id: Target agent ID
            message: Message content
        """
        # This will be implemented by the MCP orchestrator
        logger.debug(f"Agent {self.agent_id} sending message to {target_agent_id}")
    
    def receive_message(self, from_agent_id: str, message: Dict[str, Any]):
        """
        Receive message from another agent (MCP protocol)
        
        Args:
            from_agent_id: Sender agent ID
            message: Message content
        """
        logger.debug(f"Agent {self.agent_id} received message from {from_agent_id}")
    
    def __repr__(self) -> str:
        return f"<{self.agent_name} ({self.agent_id}): {self.status.value}>"
