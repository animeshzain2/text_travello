"""
Agent 4: Configuration Manager Agent
Manages routing configurations and autonomous updates
"""
from app.agents.base_agent import BaseAgent
from typing import Dict, Any, List
from datetime import datetime
import logging
import json

logger = logging.getLogger(__name__)


class ConfigManagerAgent(BaseAgent):
    """
    Manages routing configurations with version control and rollback
    Handles autonomous configuration updates with approval workflow
    """
    
    def __init__(self):
        super().__init__(
            agent_id="agent-config-manager",
            agent_name="Configuration Manager Agent",
            agent_type="configuration"
        )
        
        self.config_version = 1
        self.pending_changes = []
        self.last_update_time = datetime.now()
        
        self.metadata = {
            "config_version": self.config_version,
            "pending_changes": 0,
            "last_update": self.last_update_time.isoformat(),
            "auto_update_enabled": True
        }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute configuration task"""
        try:
            task_type = task_data.get("type", "update")
            
            if task_type == "update_config":
                result = await self._update_config(task_data)
            elif task_type == "rollback":
                result = await self._rollback_config(task_data)
            elif task_type == "validate":
                result = await self._validate_config(task_data)
            elif task_type == "get_pending":
                result = await self._get_pending_changes()
            else:
                result = {"error": f"Unknown task type: {task_type}"}
            
            self.handle_success()
            return result
            
        except Exception as e:
            self.handle_error(str(e))
            return {"error": str(e)}
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze configuration and suggest improvements"""
        try:
            current_config = data.get("current_config", {})
            performance_data = data.get("performance_data", {})
            
            analysis = {
                "config_health": self._assess_config_health(current_config, performance_data),
                "suggested_changes": self._suggest_improvements(current_config, performance_data),
                "risk_assessment": self._assess_risk(current_config),
                "timestamp": datetime.now().isoformat()
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            return {"error": str(e)}
    
    async def _update_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update routing configuration"""
        config_type = data.get("config_type", "route")
        changes = data.get("changes", {})
        requires_approval = data.get("requires_approval", True)
        
        if requires_approval:
            # Add to pending changes
            change_id = f"CHG-{len(self.pending_changes) + 1:04d}"
            self.pending_changes.append({
                "change_id": change_id,
                "config_type": config_type,
                "changes": changes,
                "requested_at": datetime.now().isoformat(),
                "status": "pending_approval"
            })
            
            self.metadata["pending_changes"] = len(self.pending_changes)
            
            return {
                "status": "pending_approval",
                "change_id": change_id,
                "message": "Configuration change requires approval",
                "timestamp": datetime.now().isoformat()
            }
        else:
            # Auto-apply (for non-critical changes)
            self.config_version += 1
            self.last_update_time = datetime.now()
            self.metadata["config_version"] = self.config_version
            self.metadata["last_update"] = self.last_update_time.isoformat()
            
            return {
                "status": "applied",
                "config_version": self.config_version,
                "changes": changes,
                "timestamp": datetime.now().isoformat()
            }
    
    async def _rollback_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Rollback to previous configuration"""
        target_version = data.get("target_version", self.config_version - 1)
        
        if target_version < 1:
            return {"error": "Invalid version number"}
        
        self.config_version = target_version
        
        return {
            "status": "rolled_back",
            "current_version": self.config_version,
            "message": f"Configuration rolled back to version {target_version}",
            "timestamp": datetime.now().isoformat()
        }
    
    async def _validate_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate configuration before applying"""
        config = data.get("config", {})
        
        validation_results = {
            "valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Validate required fields
        required_fields = ["route_id", "issuer_id", "processor_id"]
        for field in required_fields:
            if field not in config:
                validation_results["valid"] = False
                validation_results["errors"].append(f"Missing required field: {field}")
        
        # Validate values
        if config.get("timeout_ms", 0) < 100:
            validation_results["warnings"].append("Timeout is very low, may cause issues")
        
        if config.get("retry_count", 0) > 5:
            validation_results["warnings"].append("High retry count may impact performance")
        
        return validation_results
    
    async def _get_pending_changes(self) -> Dict[str, Any]:
        """Get all pending configuration changes"""
        return {
            "pending_count": len(self.pending_changes),
            "changes": self.pending_changes,
            "timestamp": datetime.now().isoformat()
        }
    
    def _assess_config_health(self, config: Dict, performance: Dict) -> str:
        """Assess configuration health"""
        issues = 0
        
        if performance.get("avg_latency", 0) > 200:
            issues += 1
        if performance.get("decline_rate", 0) > 5:
            issues += 1
        if config.get("enabled_routes", 20) < 10:
            issues += 1
        
        if issues == 0:
            return "healthy"
        elif issues <= 1:
            return "fair"
        else:
            return "poor"
    
    def _suggest_improvements(self, config: Dict, performance: Dict) -> List[Dict]:
        """Suggest configuration improvements"""
        suggestions = []
        
        if performance.get("avg_latency", 0) > 200:
            suggestions.append({
                "type": "timeout_adjustment",
                "suggestion": "Increase timeout threshold to reduce failures",
                "priority": "medium"
            })
        
        if performance.get("decline_rate", 0) > 5:
            suggestions.append({
                "type": "retry_logic",
                "suggestion": "Enable intelligent retry mechanism",
                "priority": "high"
            })
        
        if not suggestions:
            suggestions.append({
                "type": "optimization",
                "suggestion": "Configuration is optimal, no changes needed",
                "priority": "low"
            })
        
        return suggestions
    
    def _assess_risk(self, config: Dict) -> Dict[str, Any]:
        """Assess risk of configuration changes"""
        risk_level = "low"
        risk_factors = []
        
        if config.get("enabled_routes", 20) < 5:
            risk_level = "high"
            risk_factors.append("Too few enabled routes")
        
        if config.get("timeout_ms", 1000) < 500:
            risk_level = "medium"
            risk_factors.append("Low timeout may cause failures")
        
        return {
            "risk_level": risk_level,
            "risk_factors": risk_factors,
            "recommendation": "Proceed with caution" if risk_level != "low" else "Safe to proceed"
        }
