"""
MCP Orchestrator - Coordinates all AI agents using Model Context Protocol
"""
from typing import Dict, Any, List, Optional
import asyncio
import logging
from datetime import datetime

from app.agents.performance_monitor import PerformanceMonitorAgent
from app.agents.predictive_analytics import PredictiveAnalyticsAgent
from app.agents.decision_optimizer import DecisionOptimizerAgent
from app.agents.config_manager import ConfigManagerAgent
from app.agents.alerting_agent import AlertingAgent

logger = logging.getLogger(__name__)


class MCPOrchestrator:
    """
    Multi-Agent Coordinator using Model Context Protocol
    Manages communication and coordination between all AI agents
    """
    
    def __init__(self):
        """Initialize orchestrator and all agents"""
        self.agents: Dict[str, Any] = {}
        self.message_queue: List[Dict] = []
        self.running = False
        
        # Initialize all agents
        self._initialize_agents()
        
        logger.info("MCP Orchestrator initialized with 5 agents")
    
    def _initialize_agents(self):
        """Initialize all AI agents"""
        self.agents = {
            "performance_monitor": PerformanceMonitorAgent(),
            "predictive_analytics": PredictiveAnalyticsAgent(),
            "decision_optimizer": DecisionOptimizerAgent(),
            "config_manager": ConfigManagerAgent(),
            "alerting": AlertingAgent()
        }
    
    async def start_all_agents(self):
        """Start all agents"""
        self.running = True
        
        for agent_name, agent in self.agents.items():
            await agent.start()
            logger.info(f"Started agent: {agent_name}")
        
        logger.info("All agents started successfully")
    
    async def stop_all_agents(self):
        """Stop all agents"""
        self.running = False
        
        for agent_name, agent in self.agents.items():
            await agent.stop()
            logger.info(f"Stopped agent: {agent_name}")
        
        logger.info("All agents stopped")
    
    async def process_transaction(self, transaction: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process a transaction through the multi-agent system
        
        Args:
            transaction: Transaction data
            
        Returns:
            Processing results
        """
        results = {}
        
        try:
            # 1. Performance Monitor tracks the transaction
            perf_result = await self.agents["performance_monitor"].execute_task({
                "type": "track_transaction",
                "transaction": transaction
            })
            results["performance_tracking"] = perf_result
            
            # 2. Predictive Analytics analyzes patterns
            pred_result = await self.agents["predictive_analytics"].execute_task({
                "type": "detect_anomaly",
                "metrics": {
                    "latency_ms": transaction.get("latency_ms"),
                    "success": transaction.get("success")
                }
            })
            results["anomaly_detection"] = pred_result
            
            # 3. If anomaly detected, trigger alerting
            if pred_result.get("is_anomaly"):
                alert_result = await self.agents["alerting"].execute_task({
                    "type": "create_alert",
                    "severity": "warning",
                    "title": "Anomaly Detected",
                    "message": f"Anomalous transaction detected: {transaction.get('transaction_id')}",
                    "source": "predictive_analytics"
                })
                results["alert"] = alert_result
            
            return results
            
        except Exception as e:
            logger.error(f"Transaction processing failed: {str(e)}")
            return {"error": str(e)}
    
    async def optimize_routing(self, route_id: str) -> Dict[str, Any]:
        """
        Optimize a specific route using multi-agent coordination
        
        Args:
            route_id: Route to optimize
            
        Returns:
            Optimization results
        """
        try:
            # 1. Get current performance metrics
            metrics = await self.agents["performance_monitor"].execute_task({
                "type": "get_metrics"
            })
            
            route_metrics = metrics.get("route_metrics", {}).get(route_id, {})
            
            # 2. Get predictions
            predictions = await self.agents["predictive_analytics"].execute_task({
                "type": "predict_latency",
                "route_id": route_id,
                "current_latency": route_metrics.get("avg_latency_ms", 150)
            })
            
            # 3. Decision optimizer recommends actions
            optimization = await self.agents["decision_optimizer"].execute_task({
                "type": "optimize_route",
                "route_id": route_id,
                "current_metrics": route_metrics
            })
            
            # 4. Config manager applies changes (if auto-approved)
            if optimization.get("improvement_percentage", 0) > 20:
                config_update = await self.agents["config_manager"].execute_task({
                    "type": "update_config",
                    "config_type": "route",
                    "changes": optimization.get("after", {}),
                    "requires_approval": True
                })
                optimization["config_update"] = config_update
            
            # 5. Generate report
            report = await self.agents["alerting"].execute_task({
                "type": "create_alert",
                "severity": "success",
                "title": "Route Optimized",
                "message": f"Route {route_id} optimized with {optimization.get('improvement_percentage')}% improvement",
                "source": "decision_optimizer"
            })
            
            return {
                "route_id": route_id,
                "metrics": route_metrics,
                "predictions": predictions,
                "optimization": optimization,
                "report": report,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Route optimization failed: {str(e)}")
            return {"error": str(e)}
    
    async def get_all_agent_states(self) -> Dict[str, Any]:
        """Get state of all agents"""
        states = {}
        
        for agent_name, agent in self.agents.items():
            states[agent_name] = agent.get_state()
        
        return {
            "agents": states,
            "total_agents": len(self.agents),
            "orchestrator_running": self.running,
            "timestamp": datetime.now().isoformat()
        }
    
    async def send_message(self, from_agent: str, to_agent: str, message: Dict[str, Any]):
        """
        Send message between agents (MCP protocol)
        
        Args:
            from_agent: Sender agent name
            to_agent: Receiver agent name
            message: Message content
        """
        if to_agent in self.agents:
            self.agents[to_agent].receive_message(from_agent, message)
            logger.debug(f"Message sent from {from_agent} to {to_agent}")
        else:
            logger.warning(f"Agent {to_agent} not found")
    
    def get_agent(self, agent_name: str) -> Optional[Any]:
        """Get specific agent by name"""
        return self.agents.get(agent_name)


# Global orchestrator instance
orchestrator = MCPOrchestrator()
