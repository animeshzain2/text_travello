"""
Agent 1: Performance Monitor Agent
Monitors real-time transaction performance and system health
"""
from app.agents.base_agent import BaseAgent
from typing import Dict, Any, List
from datetime import datetime, timedelta
import logging
from collections import deque
from config.settings import settings

logger = logging.getLogger(__name__)


class PerformanceMonitorAgent(BaseAgent):
    """
    Monitors performance metrics for routes, issuers, and processors
    Tracks latency, success rates, and load distribution
    """
    
    def __init__(self):
        super().__init__(
            agent_id="agent-performance-monitor",
            agent_name="Performance Monitor Agent",
            agent_type="monitoring"
        )
        
        # Performance tracking
        self.metrics_buffer = deque(maxlen=1000)  # Last 1000 transactions
        self.route_metrics: Dict[str, Dict] = {}
        self.issuer_metrics: Dict[str, Dict] = {}
        self.processor_metrics: Dict[str, Dict] = {}
        
        # Thresholds
        self.latency_threshold = settings.DEFAULT_LATENCY_THRESHOLD
        self.decline_threshold = settings.DEFAULT_DECLINE_RATE_THRESHOLD
        
        self.metadata = {
            "monitoring_interval": settings.AGENT_UPDATE_INTERVAL,
            "metrics_tracked": ["latency", "success_rate", "load"],
            "thresholds": {
                "latency_ms": self.latency_threshold,
                "decline_rate": self.decline_threshold
            }
        }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute monitoring task
        
        Args:
            task_data: Task parameters (transaction data or monitoring command)
            
        Returns:
            Monitoring results
        """
        try:
            task_type = task_data.get("type", "monitor")
            
            if task_type == "monitor":
                result = await self._monitor_system()
            elif task_type == "track_transaction":
                result = await self._track_transaction(task_data.get("transaction"))
            elif task_type == "get_metrics":
                result = await self._get_current_metrics()
            else:
                result = {"error": f"Unknown task type: {task_type}"}
            
            self.handle_success()
            return result
            
        except Exception as e:
            self.handle_error(str(e))
            return {"error": str(e)}
    
    async def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze performance data
        
        Args:
            data: Performance data to analyze
            
        Returns:
            Analysis results with insights
        """
        try:
            entity_type = data.get("entity_type")  # 'route', 'issuer', 'processor'
            entity_id = data.get("entity_id")
            
            if entity_type == "route":
                metrics = self.route_metrics.get(entity_id, {})
            elif entity_type == "issuer":
                metrics = self.issuer_metrics.get(entity_id, {})
            elif entity_type == "processor":
                metrics = self.processor_metrics.get(entity_id, {})
            else:
                return {"error": "Invalid entity type"}
            
            # Analyze metrics
            analysis = {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "current_metrics": metrics,
                "health_status": self._assess_health(metrics),
                "recommendations": self._generate_recommendations(metrics),
                "timestamp": datetime.now().isoformat()
            }
            
            return analysis
            
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            return {"error": str(e)}
    
    async def _monitor_system(self) -> Dict[str, Any]:
        """Monitor overall system performance"""
        total_routes = len(self.route_metrics)
        healthy_routes = sum(1 for m in self.route_metrics.values() 
                            if m.get("load_percentage", 0) < settings.PERFORMANCE_THRESHOLD_WARNING)
        warning_routes = sum(1 for m in self.route_metrics.values() 
                            if settings.PERFORMANCE_THRESHOLD_WARNING <= m.get("load_percentage", 0) < settings.PERFORMANCE_THRESHOLD_CRITICAL)
        critical_routes = sum(1 for m in self.route_metrics.values() 
                             if m.get("load_percentage", 0) >= settings.PERFORMANCE_THRESHOLD_CRITICAL)
        
        return {
            "status": "monitoring",
            "total_routes": total_routes,
            "healthy_routes": healthy_routes,
            "warning_routes": warning_routes,
            "critical_routes": critical_routes,
            "overall_health": "healthy" if critical_routes == 0 else "degraded",
            "timestamp": datetime.now().isoformat()
        }
    
    async def _track_transaction(self, transaction: Dict[str, Any]) -> Dict[str, Any]:
        """Track individual transaction performance"""
        if not transaction:
            return {"error": "No transaction data provided"}
        
        # Add to buffer
        self.metrics_buffer.append(transaction)
        
        # Update route metrics
        route_id = transaction.get("route_id")
        if route_id:
            self._update_route_metrics(route_id, transaction)
        
        # Update issuer metrics
        issuer_id = transaction.get("issuer_id")
        if issuer_id:
            self._update_issuer_metrics(issuer_id, transaction)
        
        # Update processor metrics
        processor_id = transaction.get("processor_id")
        if processor_id:
            self._update_processor_metrics(processor_id, transaction)
        
        return {"status": "tracked", "transaction_id": transaction.get("transaction_id")}
    
    def _update_route_metrics(self, route_id: str, transaction: Dict[str, Any]):
        """Update metrics for a specific route"""
        if route_id not in self.route_metrics:
            self.route_metrics[route_id] = {
                "route_id": route_id,
                "total_transactions": 0,
                "successful_transactions": 0,
                "total_latency": 0,
                "latencies": deque(maxlen=100),
                "load_percentage": 0
            }
        
        metrics = self.route_metrics[route_id]
        metrics["total_transactions"] += 1
        
        if transaction.get("success"):
            metrics["successful_transactions"] += 1
        
        latency = transaction.get("latency_ms", 0)
        metrics["total_latency"] += latency
        metrics["latencies"].append(latency)
        
        # Calculate metrics
        metrics["avg_latency_ms"] = metrics["total_latency"] / metrics["total_transactions"]
        metrics["success_rate"] = (metrics["successful_transactions"] / metrics["total_transactions"]) * 100
        metrics["decline_rate"] = 100 - metrics["success_rate"]
        
        # Calculate load percentage (simplified)
        metrics["load_percentage"] = min(100, (metrics["total_transactions"] / 100) * 10)
        
        # Determine status and color
        load = metrics["load_percentage"]
        if load < settings.PERFORMANCE_THRESHOLD_WARNING:
            metrics["status"] = "healthy"
            metrics["color"] = "green"
        elif load < settings.PERFORMANCE_THRESHOLD_CRITICAL:
            metrics["status"] = "warning"
            metrics["color"] = "yellow"
        else:
            metrics["status"] = "critical"
            metrics["color"] = "red"
        
        metrics["last_updated"] = datetime.now().isoformat()
    
    def _update_issuer_metrics(self, issuer_id: str, transaction: Dict[str, Any]):
        """Update metrics for a specific issuer"""
        if issuer_id not in self.issuer_metrics:
            self.issuer_metrics[issuer_id] = {
                "issuer_id": issuer_id,
                "total_transactions": 0,
                "successful_transactions": 0,
                "total_latency": 0
            }
        
        metrics = self.issuer_metrics[issuer_id]
        metrics["total_transactions"] += 1
        
        if transaction.get("success"):
            metrics["successful_transactions"] += 1
        
        metrics["total_latency"] += transaction.get("latency_ms", 0)
        metrics["avg_latency_ms"] = metrics["total_latency"] / metrics["total_transactions"]
        metrics["success_rate"] = (metrics["successful_transactions"] / metrics["total_transactions"]) * 100
    
    def _update_processor_metrics(self, processor_id: str, transaction: Dict[str, Any]):
        """Update metrics for a specific processor"""
        if processor_id not in self.processor_metrics:
            self.processor_metrics[processor_id] = {
                "processor_id": processor_id,
                "total_transactions": 0,
                "successful_transactions": 0,
                "total_latency": 0
            }
        
        metrics = self.processor_metrics[processor_id]
        metrics["total_transactions"] += 1
        
        if transaction.get("success"):
            metrics["successful_transactions"] += 1
        
        metrics["total_latency"] += transaction.get("latency_ms", 0)
        metrics["avg_latency_ms"] = metrics["total_latency"] / metrics["total_transactions"]
        metrics["success_rate"] = (metrics["successful_transactions"] / metrics["total_transactions"]) * 100
    
    async def _get_current_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics"""
        return {
            "route_metrics": dict(self.route_metrics),
            "issuer_metrics": dict(self.issuer_metrics),
            "processor_metrics": dict(self.processor_metrics),
            "buffer_size": len(self.metrics_buffer),
            "timestamp": datetime.now().isoformat()
        }
    
    def _assess_health(self, metrics: Dict[str, Any]) -> str:
        """Assess health status based on metrics"""
        latency = metrics.get("avg_latency_ms", 0)
        decline_rate = metrics.get("decline_rate", 0)
        load = metrics.get("load_percentage", 0)
        
        if load >= settings.PERFORMANCE_THRESHOLD_CRITICAL or latency > self.latency_threshold * 2:
            return "critical"
        elif load >= settings.PERFORMANCE_THRESHOLD_WARNING or latency > self.latency_threshold:
            return "warning"
        else:
            return "healthy"
    
    def _generate_recommendations(self, metrics: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on metrics"""
        recommendations = []
        
        latency = metrics.get("avg_latency_ms", 0)
        decline_rate = metrics.get("decline_rate", 0)
        load = metrics.get("load_percentage", 0)
        
        if latency > self.latency_threshold:
            recommendations.append(f"High latency detected ({latency}ms). Consider route optimization.")
        
        if decline_rate > self.decline_threshold:
            recommendations.append(f"High decline rate ({decline_rate}%). Investigate issuer/processor issues.")
        
        if load >= settings.PERFORMANCE_THRESHOLD_CRITICAL:
            recommendations.append(f"Critical load ({load}%). Immediate load balancing required.")
        elif load >= settings.PERFORMANCE_THRESHOLD_WARNING:
            recommendations.append(f"Warning load ({load}%). Monitor closely and prepare for load balancing.")
        
        if not recommendations:
            recommendations.append("Performance is within acceptable parameters.")
        
        return recommendations
