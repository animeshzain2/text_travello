"""
Synthetic Data Generator - Creates realistic payment transaction data
NO CUSTOMER DATA - All data is synthetically generated for demo purposes
"""
import random
import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any
import json
from config.settings import settings


class SyntheticDataGenerator:
    """
    Generates synthetic payment transaction data for testing and demonstration
    COMPLIANCE: 100% synthetic data, no real customer information
    """
    
    def __init__(self):
        """Initialize data generator with realistic parameters"""
        
        # Issuer banks (synthetic)
        self.issuers = [
            {"id": f"ISS-{i:03d}", "name": f"Bank-{chr(65+i)}", "region": random.choice(["US", "EU", "APAC"])}
            for i in range(settings.NUM_ISSUERS)
        ]
        
        # Processors (synthetic)
        self.processors = [
            {"id": f"PROC-{i:03d}", "name": f"Processor-{i+1}", "type": random.choice(["Primary", "Backup"])}
            for i in range(settings.NUM_PROCESSORS)
        ]
        
        # Card types
        self.card_types = ["VISA", "MASTERCARD", "AMEX", "DISCOVER"]
        
        # Currencies
        self.currencies = ["USD", "EUR", "GBP", "JPY", "AUD"]
        
        # Regions
        self.regions = ["US-EAST", "US-WEST", "EU-CENTRAL", "APAC-SOUTH", "APAC-NORTH"]
        
        # Transaction types
        self.transaction_types = ["PURCHASE", "REFUND", "AUTHORIZATION", "CAPTURE"]
        
        # Merchant categories
        self.merchant_categories = [
            "Retail", "E-commerce", "Travel", "Food", "Entertainment", 
            "Healthcare", "Education", "Utilities", "Subscription"
        ]
    
    def generate_transaction(self, anomaly: bool = False) -> Dict[str, Any]:
        """
        Generate a single synthetic transaction
        
        Args:
            anomaly: If True, inject anomalous values for testing
            
        Returns:
            Synthetic transaction data
        """
        transaction_id = str(uuid.uuid4())
        timestamp = datetime.now()
        
        # Normal transaction
        if not anomaly:
            amount = round(random.uniform(10, 5000), 2)
            latency = random.randint(50, 250)  # ms
            success = random.random() > 0.05  # 95% success rate
        else:
            # Anomalous transaction
            amount = round(random.uniform(10000, 50000), 2)  # Unusually high
            latency = random.randint(500, 2000)  # High latency
            success = random.random() > 0.3  # Higher failure rate
        
        issuer = random.choice(self.issuers)
        processor = random.choice(self.processors)
        
        transaction = {
            "transaction_id": transaction_id,
            "timestamp": timestamp.isoformat(),
            "amount": amount,
            "currency": random.choice(self.currencies),
            "card_type": random.choice(self.card_types),
            "card_last_4": f"{random.randint(1000, 9999)}",  # Synthetic card number
            "merchant_id": f"MERCH-{random.randint(1000, 9999)}",
            "merchant_category": random.choice(self.merchant_categories),
            "transaction_type": random.choice(self.transaction_types),
            "region": random.choice(self.regions),
            "issuer_id": issuer["id"],
            "issuer_name": issuer["name"],
            "processor_id": processor["id"],
            "processor_name": processor["name"],
            "route_id": f"ROUTE-{random.randint(1, 20):02d}",
            "latency_ms": latency,
            "success": success,
            "decline_reason": None if success else random.choice([
                "INSUFFICIENT_FUNDS", "INVALID_CARD", "FRAUD_SUSPECTED", 
                "ISSUER_UNAVAILABLE", "TIMEOUT"
            ]),
            "is_anomaly": anomaly
        }
        
        return transaction
    
    def generate_batch(self, count: int = 100, anomaly_rate: float = 0.05) -> List[Dict[str, Any]]:
        """
        Generate a batch of synthetic transactions
        
        Args:
            count: Number of transactions to generate
            anomaly_rate: Percentage of anomalous transactions (0.0 to 1.0)
            
        Returns:
            List of synthetic transactions
        """
        transactions = []
        num_anomalies = int(count * anomaly_rate)
        
        for i in range(count):
            is_anomaly = i < num_anomalies
            transactions.append(self.generate_transaction(anomaly=is_anomaly))
        
        # Shuffle to distribute anomalies randomly
        random.shuffle(transactions)
        return transactions
    
    def generate_performance_metrics(self, route_id: str) -> Dict[str, Any]:
        """
        Generate synthetic performance metrics for a route
        
        Args:
            route_id: Route identifier
            
        Returns:
            Performance metrics
        """
        # Random but realistic performance
        base_latency = random.randint(80, 200)
        load_percentage = random.uniform(40, 95)
        
        # Color coding based on load
        if load_percentage < 80:
            status = "healthy"
            color = "green"
        elif load_percentage < 90:
            status = "warning"
            color = "yellow"
        else:
            status = "critical"
            color = "red"
        
        return {
            "route_id": route_id,
            "avg_latency_ms": base_latency,
            "p95_latency_ms": base_latency + random.randint(20, 100),
            "p99_latency_ms": base_latency + random.randint(50, 200),
            "success_rate": round(random.uniform(92, 99.5), 2),
            "decline_rate": round(random.uniform(0.5, 8), 2),
            "transactions_per_minute": random.randint(50, 500),
            "load_percentage": round(load_percentage, 1),
            "status": status,
            "color": color,
            "last_updated": datetime.now().isoformat()
        }
    
    def generate_issuer_performance(self, issuer_id: str) -> Dict[str, Any]:
        """
        Generate synthetic issuer performance data
        
        Args:
            issuer_id: Issuer identifier
            
        Returns:
            Issuer performance metrics
        """
        return {
            "issuer_id": issuer_id,
            "uptime_percentage": round(random.uniform(98, 100), 2),
            "avg_response_time_ms": random.randint(100, 300),
            "success_rate": round(random.uniform(94, 99), 2),
            "capacity_used": round(random.uniform(50, 90), 1),
            "active_connections": random.randint(100, 1000),
            "last_downtime": (datetime.now() - timedelta(hours=random.randint(24, 720))).isoformat()
        }
    
    def generate_processor_performance(self, processor_id: str) -> Dict[str, Any]:
        """
        Generate synthetic processor performance data
        
        Args:
            processor_id: Processor identifier
            
        Returns:
            Processor performance metrics
        """
        return {
            "processor_id": processor_id,
            "throughput_tps": random.randint(500, 5000),
            "avg_latency_ms": random.randint(50, 150),
            "error_rate": round(random.uniform(0.1, 2), 2),
            "capacity_percentage": round(random.uniform(60, 95), 1),
            "queue_depth": random.randint(0, 100),
            "health_status": random.choice(["healthy", "degraded", "healthy", "healthy"])  # Mostly healthy
        }
    
    def generate_routing_table(self) -> List[Dict[str, Any]]:
        """
        Generate synthetic routing configuration table
        
        Returns:
            List of route configurations
        """
        routes = []
        
        for i in range(20):  # 20 routes
            route = {
                "route_id": f"ROUTE-{i+1:02d}",
                "name": f"Route {chr(65 + (i % 26))}{i+1}",
                "issuer_id": random.choice(self.issuers)["id"],
                "processor_id": random.choice(self.processors)["id"],
                "priority": random.randint(1, 10),
                "enabled": random.random() > 0.1,  # 90% enabled
                "card_types": random.sample(self.card_types, k=random.randint(1, 4)),
                "regions": random.sample(self.regions, k=random.randint(1, 3)),
                "max_amount": random.choice([1000, 5000, 10000, 50000]),
                "retry_count": random.randint(1, 3),
                "timeout_ms": random.choice([500, 1000, 2000, 3000]),
                "created_at": (datetime.now() - timedelta(days=random.randint(1, 365))).isoformat(),
                "updated_at": (datetime.now() - timedelta(hours=random.randint(1, 48))).isoformat()
            }
            routes.append(route)
        
        return routes
    
    def generate_time_series_data(self, hours: int = 24, interval_minutes: int = 5) -> List[Dict[str, Any]]:
        """
        Generate time-series performance data for charts
        
        Args:
            hours: Number of hours of historical data
            interval_minutes: Data point interval in minutes
            
        Returns:
            Time-series data points
        """
        data_points = []
        start_time = datetime.now() - timedelta(hours=hours)
        num_points = (hours * 60) // interval_minutes
        
        # Base values with trend
        base_latency = 150
        base_success_rate = 96
        
        for i in range(num_points):
            timestamp = start_time + timedelta(minutes=i * interval_minutes)
            
            # Add some realistic variation and trends
            time_factor = i / num_points
            latency = base_latency + random.randint(-30, 30) - (time_factor * 20)  # Improving trend
            success_rate = base_success_rate + random.uniform(-2, 2) + (time_factor * 2)  # Improving trend
            
            data_point = {
                "timestamp": timestamp.isoformat(),
                "avg_latency_ms": max(50, round(latency, 1)),
                "success_rate": min(99.9, max(90, round(success_rate, 2))),
                "transactions_count": random.randint(800, 1200),
                "decline_count": random.randint(10, 50),
                "active_routes": random.randint(18, 20)
            }
            data_points.append(data_point)
        
        return data_points
    
    def save_to_file(self, data: Any, filename: str):
        """
        Save generated data to JSON file
        
        Args:
            data: Data to save
            filename: Output filename
        """
        filepath = f"data/{filename}"
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Data saved to {filepath}")


# Global instance
data_generator = SyntheticDataGenerator()


# Generate sample datasets on import
if __name__ == "__main__":
    print("Generating synthetic datasets...")
    
    # Generate sample transactions
    transactions = data_generator.generate_batch(count=1000)
    data_generator.save_to_file(transactions, "sample_transactions.json")
    
    # Generate routing table
    routing_table = data_generator.generate_routing_table()
    data_generator.save_to_file(routing_table, "routing_table.json")
    
    # Generate time-series data
    time_series = data_generator.generate_time_series_data(hours=24)
    data_generator.save_to_file(time_series, "time_series_24h.json")
    
    print("Synthetic data generation complete!")
