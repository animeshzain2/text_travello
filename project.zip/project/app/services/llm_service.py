"""
LLM Service - Integration with DeepSeek via LangChain
"""
from langchain_openai import ChatOpenAI
import httpx
from typing import Optional, Dict, Any
from config.settings import settings
import logging

logger = logging.getLogger(__name__)


class LLMService:
    """
    Service for interacting with LLM (DeepSeek) for intelligent decision making
    """
    
    def __init__(self):
        """Initialize LLM client"""
        # Create HTTP client with SSL verification disabled (as per provided code)
        self.http_client = httpx.Client(verify=False)
        
        # Initialize LangChain ChatOpenAI with DeepSeek configuration
        self.llm = ChatOpenAI(
            base_url=settings.LLM_BASE_URL,
            model=settings.LLM_MODEL,
            api_key=settings.LLM_API_KEY,
            http_client=self.http_client
        )
        
        logger.info("LLM Service initialized successfully")
    
    def analyze_routing_decision(
        self, 
        transaction_data: Dict[str, Any],
        performance_metrics: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Use LLM to analyze routing decision based on transaction and performance data
        
        Args:
            transaction_data: Transaction details
            performance_metrics: Current performance metrics
            
        Returns:
            LLM analysis and recommendations
        """
        try:
            prompt = f"""
            You are an expert payment routing optimization agent. Analyze the following data and provide routing recommendations.
            
            Transaction Data:
            - Amount: {transaction_data.get('amount')}
            - Currency: {transaction_data.get('currency')}
            - Card Type: {transaction_data.get('card_type')}
            - Region: {transaction_data.get('region')}
            
            Current Performance Metrics:
            - Available Routes: {performance_metrics.get('available_routes')}
            - Average Latency: {performance_metrics.get('avg_latency')}ms
            - Decline Rate: {performance_metrics.get('decline_rate')}%
            - Load Distribution: {performance_metrics.get('load_distribution')}
            
            Provide:
            1. Recommended route
            2. Reasoning for the recommendation
            3. Risk assessment
            4. Alternative routes if primary fails
            
            Format your response as JSON.
            """
            
            response = self.llm.invoke(prompt)
            
            logger.info("LLM routing analysis completed")
            return {
                "success": True,
                "analysis": response.content,
                "model": settings.LLM_MODEL
            }
            
        except Exception as e:
            logger.error(f"LLM analysis failed: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "fallback": "Using rule-based routing"
            }
    
    def explain_anomaly(self, anomaly_data: Dict[str, Any]) -> str:
        """
        Use LLM to explain detected anomalies in human-readable format
        
        Args:
            anomaly_data: Anomaly details
            
        Returns:
            Human-readable explanation
        """
        try:
            prompt = f"""
            Explain the following payment routing anomaly in simple terms:
            
            Anomaly Type: {anomaly_data.get('type')}
            Severity: {anomaly_data.get('severity')}
            Affected Route: {anomaly_data.get('route')}
            Metrics: {anomaly_data.get('metrics')}
            
            Provide:
            1. What happened
            2. Why it's concerning
            3. Recommended action
            
            Keep it concise and actionable.
            """
            
            response = self.llm.invoke(prompt)
            return response.content
            
        except Exception as e:
            logger.error(f"LLM anomaly explanation failed: {str(e)}")
            return f"Anomaly detected: {anomaly_data.get('type')} - Manual review recommended"
    
    def generate_optimization_strategy(
        self, 
        current_state: Dict[str, Any],
        historical_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate optimization strategy using LLM analysis
        
        Args:
            current_state: Current routing state
            historical_data: Historical performance data
            
        Returns:
            Optimization strategy
        """
        try:
            prompt = f"""
            As a payment routing optimization expert, create an optimization strategy.
            
            Current State:
            - Total Routes: {current_state.get('total_routes')}
            - Active Transactions: {current_state.get('active_transactions')}
            - System Load: {current_state.get('system_load')}%
            - Recent Failures: {current_state.get('recent_failures')}
            
            Historical Performance (Last 24h):
            - Average Latency: {historical_data.get('avg_latency')}ms
            - Success Rate: {historical_data.get('success_rate')}%
            - Peak Load Time: {historical_data.get('peak_load_time')}
            
            Provide an optimization strategy including:
            1. Load balancing adjustments
            2. Route priority changes
            3. Capacity planning recommendations
            4. Expected improvements
            
            Format as JSON with actionable steps.
            """
            
            response = self.llm.invoke(prompt)
            
            return {
                "success": True,
                "strategy": response.content,
                "timestamp": "now"
            }
            
        except Exception as e:
            logger.error(f"LLM optimization strategy failed: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }
    
    def chat_query(self, user_query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """
        Handle natural language queries about the system
        
        Args:
            user_query: User's question
            context: Optional context data
            
        Returns:
            LLM response
        """
        try:
            if context:
                prompt = f"""
                Context: {context}
                
                User Question: {user_query}
                
                Provide a helpful, accurate response based on the payment routing system context.
                """
            else:
                prompt = user_query
            
            response = self.llm.invoke(prompt)
            return response.content
            
        except Exception as e:
            logger.error(f"LLM chat query failed: {str(e)}")
            return "I apologize, but I'm unable to process your query at the moment. Please try again."
    
    def __del__(self):
        """Cleanup HTTP client"""
        if hasattr(self, 'http_client'):
            self.http_client.close()


# Global LLM service instance
llm_service = LLMService()
