"""
Configuration settings for the Intelligent Routing Optimization Agent
"""
from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    APP_NAME: str = "Intelligent Routing Optimization Agent"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # LLM Configuration (DeepSeek via LangChain)
    LLM_BASE_URL: str = "https://genailab.tcs.in"
    LLM_MODEL: str = "azure_ai/genailab-maas-DeepSeek-V3-0324"
    LLM_API_KEY: str = "XXXXXXXXXXX"
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 2000
    
    # Database
    DATABASE_URL: str = "sqlite:///./data/routing_agent.db"  # SQLite for easy setup
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Agent Configuration
    AGENT_UPDATE_INTERVAL: int = 5  # seconds
    PERFORMANCE_THRESHOLD_WARNING: float = 80.0  # percentage
    PERFORMANCE_THRESHOLD_CRITICAL: float = 90.0  # percentage
    
    # Routing Configuration
    DEFAULT_LATENCY_THRESHOLD: int = 200  # milliseconds
    DEFAULT_DECLINE_RATE_THRESHOLD: float = 5.0  # percentage
    MAX_RETRIES: int = 3
    CIRCUIT_BREAKER_THRESHOLD: int = 5
    
    # Synthetic Data Generation
    TRANSACTION_VOLUME_PER_MINUTE: int = 1000
    NUM_ISSUERS: int = 8
    NUM_PROCESSORS: int = 12
    
    # WebSocket
    WS_HEARTBEAT_INTERVAL: int = 30  # seconds
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS
    CORS_ORIGINS: list = [
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/app.log"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()
