// Main Application Logic

let selectedInterests = new Set();
let selectedDuration = 3;
let map = null;
let markers = [];

function startPlanning() {
    const landingPage = document.getElementById('landing-page');
    const appContainer = document.getElementById('app-container');

    // Simple transition
    landingPage.classList.add('hidden');
    appContainer.classList.remove('hidden');

    // Render the Preference Form
    renderPreferenceForm();
}

function showLandingPage() {
    const landingPage = document.getElementById('landing-page');
    const appContainer = document.getElementById('app-container');

    if (appContainer) {
        appContainer.classList.add('hidden');
    }
    if (landingPage) {
        landingPage.classList.remove('hidden');
    }
    window.scrollTo(0, 0);
}

function renderPreferenceForm() {
    const container = document.getElementById('app-container');
    container.innerHTML = `
        <div class="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
            <div class="bg-brand-50 p-6 border-b border-brand-100">
                <h2 class="text-2xl font-bold text-brand-900">Tell us about your trip</h2>
                <p class="text-brand-700">Help our AI agent design the perfect itinerary for you.</p>
            </div>
            
            <div class="p-8 space-y-6">
                <!-- Step 1: Destination & Source -->
                <div class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Where are you starting from?</label>
                        <div class="relative">
                            <i class="fas fa-plane-departure absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                            <input type="text" id="source" placeholder="e.g., New Delhi, London" 
                                class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-none transition-all text-lg"
                            >
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Where do you want to go?</label>
                        <div class="relative">
                            <i class="fas fa-location-dot absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                            <input type="text" id="destination" placeholder="e.g., Paris, Tokyo" 
                                class="w-full pl-12 pr-4 py-3 rounded-xl border border-gray-200 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 outline-none transition-all text-lg"
                            >
                        </div>
                    </div>
                </div>

                <!-- Duration -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">How many days?</label>
                    <div class="flex gap-4">
                        <button onclick="selectDuration(3)" id="dur-3" class="duration-btn flex-1 py-3 border border-slate-200 rounded-lg hover:border-brand-500 hover:bg-brand-50 transition-all focus:ring-2 focus:ring-brand-500 bg-brand-50 border-brand-500 ring-2 ring-brand-500">3 Days</button>
                        <button onclick="selectDuration(5)" id="dur-5" class="duration-btn flex-1 py-3 border border-slate-200 rounded-lg hover:border-brand-500 hover:bg-brand-50 transition-all focus:ring-2 focus:ring-brand-500">5 Days</button>
                        <button onclick="selectDuration(7)" id="dur-7" class="duration-btn flex-1 py-3 border border-slate-200 rounded-lg hover:border-brand-500 hover:bg-brand-50 transition-all focus:ring-2 focus:ring-brand-500">7 Days</button>
                    </div>
                </div>

                <!-- Budget -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">What's your budget?</label>
                    <div class="grid grid-cols-3 gap-4">
                        <label class="cursor-pointer">
                            <input type="radio" name="budget" value="budget" class="peer sr-only">
                            <div class="p-4 border border-slate-200 rounded-lg peer-checked:border-brand-500 peer-checked:bg-brand-50 hover:bg-slate-50 transition-all text-center">
                                <div class="text-xl mb-1">💸</div>
                                <div class="font-medium text-slate-900">Budget</div>
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="budget" value="moderate" class="peer sr-only" checked>
                            <div class="p-4 border border-slate-200 rounded-lg peer-checked:border-brand-500 peer-checked:bg-brand-50 hover:bg-slate-50 transition-all text-center">
                                <div class="text-xl mb-1">💰</div>
                                <div class="font-medium text-slate-900">Moderate</div>
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="budget" value="luxury" class="peer sr-only">
                            <div class="p-4 border border-slate-200 rounded-lg peer-checked:border-brand-500 peer-checked:bg-brand-50 hover:bg-slate-50 transition-all text-center">
                                <div class="text-xl mb-1">💎</div>
                                <div class="font-medium text-slate-900">Luxury</div>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Travel Vibe (New Feature) -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Travel Vibe ✨</label>
                    <div class="grid grid-cols-2 gap-4">
                        <label class="cursor-pointer">
                            <input type="radio" name="vibe" value="tourist" class="peer sr-only" checked>
                            <div class="p-4 border border-slate-200 rounded-lg peer-checked:border-brand-500 peer-checked:bg-brand-50 hover:bg-slate-50 transition-all text-center relative overflow-hidden">
                                <div class="text-xl mb-1">📸</div>
                                <div class="font-medium text-slate-900">Tourist Hotspots</div>
                                <div class="text-xs text-slate-500 mt-1">Must-see landmarks</div>
                            </div>
                        </label>
                        <label class="cursor-pointer">
                            <input type="radio" name="vibe" value="local" class="peer sr-only">
                            <div class="p-4 border border-slate-200 rounded-lg peer-checked:border-brand-500 peer-checked:bg-brand-50 hover:bg-slate-50 transition-all text-center relative overflow-hidden">
                                <div class="text-xl mb-1">🔍</div>
                                <div class="font-medium text-slate-900">Hidden Gems</div>
                                <div class="text-xs text-slate-500 mt-1">Local secrets & culture</div>
                                <div class="absolute top-0 right-0 bg-brand-500 text-white text-[10px] px-2 py-0.5 rounded-bl-lg">NEW</div>
                            </div>
                        </label>
                    </div>
                </div>

                <!-- Interests -->
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-2">Interests (Select all that apply)</label>
                    <div class="flex flex-wrap gap-2" id="interests-container">
                        <button onclick="toggleInterest(this, 'History')" class="interest-btn px-4 py-2 rounded-full border border-slate-200 text-slate-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-700 transition-colors">🏛️ History</button>
                        <button onclick="toggleInterest(this, 'Art')" class="interest-btn px-4 py-2 rounded-full border border-slate-200 text-slate-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-700 transition-colors">🎨 Art</button>
                        <button onclick="toggleInterest(this, 'Food')" class="interest-btn px-4 py-2 rounded-full border border-slate-200 text-slate-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-700 transition-colors">🍜 Food</button>
                        <button onclick="toggleInterest(this, 'Nature')" class="interest-btn px-4 py-2 rounded-full border border-slate-200 text-slate-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-700 transition-colors">🌳 Nature</button>
                        <button onclick="toggleInterest(this, 'Shopping')" class="interest-btn px-4 py-2 rounded-full border border-slate-200 text-slate-600 hover:bg-brand-50 hover:border-brand-200 hover:text-brand-700 transition-colors">🛍️ Shopping</button>
                    </div>
                </div>

                <div class="pt-4">
                    <button onclick="generateItinerary()" class="w-full bg-brand-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-brand-700 transition-colors shadow-lg shadow-brand-500/30 flex justify-center items-center gap-2">
                        <span>✨ Generate Itinerary</span>
                    </button>
                </div>
            </div>
        </div>
    `;
}

function selectDuration(days) {
    selectedDuration = days;
    document.querySelectorAll('.duration-btn').forEach(btn => {
        btn.classList.remove('bg-brand-50', 'border-brand-500', 'ring-2', 'ring-brand-500');
    });
    document.getElementById(`dur-${days}`).classList.add('bg-brand-50', 'border-brand-500', 'ring-2', 'ring-brand-500');
}

function toggleInterest(btn, interest) {
    if (selectedInterests.has(interest)) {
        selectedInterests.delete(interest);
        btn.classList.remove('bg-brand-100', 'border-brand-500', 'text-brand-800');
    } else {
        selectedInterests.add(interest);
        btn.classList.add('bg-brand-100', 'border-brand-500', 'text-brand-800');
    }
}

async function generateItinerary() {
    const sourceInput = document.getElementById('source');
    const destinationInput = document.getElementById('destination');

    const source = sourceInput ? sourceInput.value.trim() : "";
    const destination = destinationInput ? destinationInput.value.trim() : "";

    if (!destination) {
        alert("Please enter a destination");
        return;
    }
    if (!source) {
        alert("Please enter a starting location");
        return;
    }

    const budgetInput = document.querySelector('input[name="budget"]:checked');
    const budget = budgetInput ? budgetInput.value : "moderate";

    // Get vibe
    const vibeInput = document.querySelector('input[name="vibe"]:checked');
    const vibe = vibeInput ? vibeInput.value : "tourist";

    const interests = Array.from(selectedInterests);

    const container = document.getElementById('app-container');
    container.innerHTML = `
        <div class="flex flex-col items-center justify-center py-20">
            <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-brand-600 mb-6"></div>
            <h2 class="text-2xl font-bold text-slate-800 mb-2">Designing your perfect ${vibe === 'local' ? 'hidden gem' : 'classic'} trip to ${destination}...</h2>
            <p class="text-slate-500">Finding the best spots and checking weather contingencies.</p>
        </div>
    `;

    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                source: source,
                destination: destination,
                days: selectedDuration,
                budget: budget,
                vibe: vibe,
                interests: interests
            })
        });

        if (!response.ok) throw new Error('Generation failed');

        const data = await response.json();
        renderItinerary(data);

    } catch (error) {
        console.error('Error:', error);
        alert('Failed to generate itinerary. Please try again.');
        renderPreferenceForm();
    }
}

function renderItinerary(data) {
    const container = document.getElementById('app-container');

    // Store current itinerary data for modifications
    currentItineraryData = data;

    // Essentials Card HTML - NOW AT BOTTOM
    let essentialsHtml = '';
    if (data.trip_essentials) {
        const ess = data.trip_essentials;

        const packingList = ess.packing_list ? ess.packing_list.map(item => `<li class="text-sm text-slate-300 font-semibold">${item}</li>`).join('') : '<li class="text-sm text-slate-300 font-semibold">Standard travel gear</li>';
        const safetyTips = ess.safety_tips ? ess.safety_tips.map(item => `<li class="text-sm text-slate-300 font-semibold">${item}</li>`).join('') : '<li class="text-sm text-slate-300 font-semibold">Standard safety precautions</li>';
        const culturalNorms = ess.cultural_norms ? ess.cultural_norms.map(item => `<li class="text-sm text-slate-300 font-semibold">${item}</li>`).join('') : '<li class="text-sm text-slate-300 font-semibold">Be respectful</li>';

        essentialsHtml = `
            <div class="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 shadow-lg mt-8 text-white">
                <h3 class="text-xl font-bold mb-4 flex items-center gap-2">
                    <span class="bg-white/20 p-1.5 rounded-lg">🛡️</span> Trip Essentials
                </h3>
                
                <div class="space-y-6">
                    <!-- Weather & Packing - FULL WIDTH BLOCK -->
                    <div class="bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                        <h4 class="font-semibold text-brand-200 mb-3 flex items-center gap-2">
                            <i class="fas fa-cloud-sun"></i> Weather & Packing
                        </h4>
                        <p class="text-sm text-slate-200 mb-3 italic leading-relaxed">"${ess.weather_info || 'Check local forecast'}"</p>
                        <ul class="space-y-1.5 list-none">
                            ${packingList}
                        </ul>
                    </div>
                    
                    <!-- Safety & Culture - FULL WIDTH BLOCK -->
                    <div class="bg-white/10 rounded-xl p-4 backdrop-blur-sm">
                        <h4 class="font-semibold text-red-200 mb-3 flex items-center gap-2">
                            <i class="fas fa-shield-alt"></i> Safety & Culture
                        </h4>
                        <div class="mb-4">
                            <p class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Safety Tips</p>
                            <ul class="space-y-1.5 list-none">
                                ${safetyTips}
                            </ul>
                        </div>
                        <div>
                            <p class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Cultural Norms</p>
                            <ul class="space-y-1.5 list-none">
                                ${culturalNorms}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    let daysHtml = '';
    if (data.days && Array.isArray(data.days)) {
        data.days.forEach((day, index) => {
            let activitiesHtml = '';
            if (day.activities && Array.isArray(day.activities)) {
                day.activities.forEach(act => {
                    const icon = getIconForType(act.type);

                    // Rainy Day Logic
                    let rainyDayHtml = '';
                    if (act.rainy_day_alternative && act.rainy_day_alternative !== 'N/A') {
                        rainyDayHtml = `
                            <div class="mt-3 pt-3 border-t border-slate-50 flex items-start gap-2 text-sm text-slate-500">
                                <span class="text-blue-400" title="Rainy Day Option">☔</span>
                                <div>
                                    <span class="font-medium text-slate-700">Rainy Day Plan:</span> 
                                    ${act.rainy_day_alternative}
                                </div>
                            </div>
                        `;
                    }

                    activitiesHtml += `
                        <div class="relative pl-8 pb-8 border-l-2 border-brand-100 last:border-0 last:pb-0">
                            <div class="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-brand-500 ring-4 ring-brand-50"></div>
                            <div class="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="text-sm font-semibold text-brand-600 bg-brand-50 px-2 py-1 rounded-md">${act.time}</span>
                                    <span class="text-lg">${icon}</span>
                                </div>
                                <h4 class="text-lg font-bold text-slate-800">${act.title}</h4>
                                <p class="text-slate-600 text-sm mt-1">${act.description}</p>
                                ${rainyDayHtml}
                            </div>
                        </div>
                    `;
                });
            }

            daysHtml += `
                <div class="mb-8 last:mb-0">
                    <h3 class="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <span class="bg-slate-900 text-white w-8 h-8 rounded-lg flex items-center justify-center text-sm">D${day.day}</span>
                        ${day.theme}
                    </h3>
                    <div class="ml-4">
                        ${activitiesHtml}
                    </div>
                </div>
            `;
        });
    }

    container.innerHTML = `
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[calc(100vh-100px)]">
            <!-- Timeline Column -->
            <div class="lg:col-span-1 overflow-y-auto pr-2 custom-scrollbar">
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-bold text-slate-900">${data.destination}</h2>
                        <button onclick="showModificationPrompt()" class="text-sm text-brand-600 hover:text-brand-700 font-medium flex items-center gap-1 no-print">
                            <i class="fas fa-edit"></i> Modify
                        </button>
                    </div>
                    
                    <!-- Modification Prompt (Hidden by default) -->
                    <div id="modification-prompt" class="hidden mb-6 bg-brand-50 border border-brand-200 rounded-xl p-4">
                        <h3 class="text-sm font-bold text-brand-900 mb-2 flex items-center gap-2">
                            <i class="fas fa-magic"></i> Request Changes
                        </h3>
                        <p class="text-xs text-brand-700 mb-3">Tell me what you'd like to change about your itinerary...</p>
                        <textarea 
                            id="modification-input" 
                            placeholder="e.g., Add more food experiences, replace Day 2 activities with museums, make it more budget-friendly..."
                            class="w-full p-3 border border-brand-300 rounded-lg text-sm resize-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
                            rows="3"
                        ></textarea>
                        <div class="flex gap-2 mt-3">
                            <button 
                                onclick="applyModifications()" 
                                class="flex-1 bg-brand-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-brand-700 transition-colors flex items-center justify-center gap-2"
                            >
                                <i class="fas fa-check"></i> Apply Changes
                            </button>
                            <button 
                                onclick="hideModificationPrompt()" 
                                class="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                    
                    <!-- Days -->
                    ${daysHtml}
                    
                    ${essentialsHtml}
                    
                    <div class="mt-8 pt-6 border-t border-slate-100 no-print">
                        <button onclick="window.print()" class="w-full py-3 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800 transition-colors">
                            Download PDF / Print
                        </button>
                    </div>
                </div>
            </div>

            <!-- Map Column -->
            <div class="lg:col-span-2 bg-slate-100 rounded-2xl overflow-hidden shadow-inner relative h-full min-h-[500px]">
                <div id="map" class="w-full h-full z-0"></div>
                
                <!-- Map Overlay Controls -->
                <div class="absolute top-4 right-4 z-[400] flex gap-2">
                    <button class="bg-white p-2 rounded-lg shadow-md hover:bg-slate-50 text-slate-700">
                        🗺️ Map View
                    </button>
                </div>
            </div>
        </div>
    `;

    // Initialize Map
    setTimeout(() => {
        initMap(data);
    }, 100);
}

function getIconForType(type) {
    const icons = {
        culture: '⛩️',
        shopping: '🛍️',
        food: '🍱',
        sightseeing: '📸',
        art: '🎨',
        nature: '🌳'
    };
    return icons[type] || '📍';
}

function initMap(data) {
    if (map) {
        map.remove();
        map = null;
    }

    // Default to first activity or Tokyo
    let startLat = 35.6762;
    let startLng = 139.6503;

    if (data.destination_lat && data.destination_lng) {
        startLat = data.destination_lat;
        startLng = data.destination_lng;
    }

    map = L.map('map').setView([startLat, startLng], 13);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(map);

    markers = [];
    const pathCoordinates = [];

    // Add Source Marker
    if (data.source_lat && data.source_lng) {
        const sourceMarker = L.marker([data.source_lat, data.source_lng], {
            icon: L.divIcon({
                className: 'custom-div-icon',
                html: `<div style="background-color: #10B981; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></div>`,
                iconSize: [16, 16],
                iconAnchor: [8, 8]
            })
        }).addTo(map).bindPopup(`<b>Start:</b> ${data.source}`);
        markers.push(sourceMarker);
        pathCoordinates.push([data.source_lat, data.source_lng]);
    }

    // Add Activity Markers
    if (data.days) {
        data.days.forEach(day => {
            day.activities.forEach(act => {
                if (act.lat && act.lng) {
                    const marker = L.marker([act.lat, act.lng])
                        .addTo(map)
                        .bindPopup(`<b>${act.title}</b><br>${act.description}`);
                    markers.push(marker);
                    pathCoordinates.push([act.lat, act.lng]);
                }
            });
        });
    }

    // Draw route line
    if (pathCoordinates.length > 1) {
        L.polyline(pathCoordinates, {
            color: '#0d9488', // Brand color
            weight: 4,
            opacity: 0.7,
            dashArray: '10, 10',
            lineCap: 'round'
        }).addTo(map);
    }

    // Fit bounds
    if (markers.length > 0) {
        const group = new L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
}



// Chat Interface Logic
function startChat() {
    document.getElementById('chat-container').classList.remove('hidden');
    document.getElementById('chat-input').focus();
}

function closeChat() {
    document.getElementById('chat-container').classList.add('hidden');
    // Clear chat history when closing
    chatHistory = [];
}

// Chat history storage
let chatHistory = [];

async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (!message) return;

    // Add User Message to UI
    addMessageToChat(message, 'user');
    input.value = '';

    // Show Typing Indicator
    const typingId = addTypingIndicator();

    try {
        // Send request with history BEFORE adding current message
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                history: chatHistory
            })
        });

        if (!response.ok) throw new Error('Chat failed');

        const data = await response.json();

        // Parse the response
        let aiResponseText = data.response;
        let planTripData = null;

        try {
            let parsedResponse = null;
            // Check if response is already an object
            if (typeof data.response === 'object' && data.response !== null) {
                parsedResponse = data.response;
            }
            // Check if response is a string
            else if (typeof data.response === 'string') {
                // Clean potential markdown just in case
                const cleanStr = data.response.replace(/```json/g, '').replace(/```/g, '').trim();
                if (cleanStr.startsWith('{') || cleanStr.startsWith('[')) {
                    parsedResponse = JSON.parse(cleanStr);
                }
            }

            if (parsedResponse) {
                if (parsedResponse.text) {
                    aiResponseText = parsedResponse.text;
                }
                if (parsedResponse.plan_trip && parsedResponse.plan_trip.ready) {
                    planTripData = parsedResponse.plan_trip;
                }
            }
        } catch (e) {
            console.log("Response parsing error:", e);
        }

        removeTypingIndicator(typingId);

        // Add AI response to UI
        addMessageToChat(aiResponseText, 'ai');

        // If ready to plan, add the button
        if (planTripData) {
            addPlanTripButton(planTripData);
        }

        // Add to history AFTER successful send
        chatHistory.push({
            role: 'user',
            content: message
        });

        // Add AI response to history
        chatHistory.push({
            role: 'assistant',
            content: aiResponseText
        });

    } catch (error) {
        console.error('Chat Error:', error);
        removeTypingIndicator(typingId);
        addMessageToChat("Sorry, I'm having trouble connecting right now.", 'ai');
    }
}

function addMessageToChat(text, sender) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`;

    const avatar = sender === 'ai'
        ? `<div class="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0"><i class="fas fa-robot text-brand-600 text-sm"></i></div>`
        : `<div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0"><i class="fas fa-user text-blue-600 text-sm"></i></div>`;

    const bubbleClass = sender === 'ai'
        ? 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
        : 'bg-brand-600 text-white rounded-tr-none shadow-md shadow-brand-500/20';

    div.innerHTML = `
        ${sender === 'ai' ? avatar : ''}
        <div class="${bubbleClass} p-4 rounded-2xl shadow-sm max-w-[80%] ${sender === 'ai' ? 'ml-3' : 'mr-3'}">
            <p>${text}</p>
        </div>
        ${sender === 'user' ? avatar : ''}
    `;

    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function addPlanTripButton(planData) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = 'flex justify-start pl-11 mb-4'; // Indent to align with AI bubble

    // Store data in a way we can access it
    const dataString = JSON.stringify(planData).replace(/"/g, '&quot;');

    div.innerHTML = `
        <button onclick="triggerPlanTrip(${dataString})" 
            class="bg-brand-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-brand-500/30 hover:bg-brand-700 transition-all transform hover:scale-105 flex items-center gap-2">
            <span>✨ Plan My Trip Now</span>
            <i class="fas fa-arrow-right"></i>
        </button>
    `;

    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function triggerPlanTrip(data) {
    // Close chat
    closeChat();

    // Ensure we are in the planning view
    // Ensure we are in the planning view
    const landingPage = document.getElementById('landing-page');
    const appContainer = document.getElementById('app-container');

    if (landingPage && !landingPage.classList.contains('hidden')) {
        landingPage.classList.add('hidden');
    }
    if (appContainer && appContainer.classList.contains('hidden')) {
        appContainer.classList.remove('hidden');
    }

    // Ensure form is rendered if inputs don't exist
    if (!document.getElementById('source')) {
        renderPreferenceForm();
    }

    // Populate Form
    if (data.source) {
        const sourceInput = document.getElementById('source');
        if (sourceInput) sourceInput.value = data.source;
    }
    if (data.destination) {
        const destInput = document.getElementById('destination');
        if (destInput) destInput.value = data.destination;
    }

    // Set Duration
    if (data.days) {
        selectDuration(data.days);
    }

    // Set Budget
    if (data.budget) {
        const budgetRadio = document.querySelector(`input[name="budget"][value="${data.budget.toLowerCase()}"]`);
        if (budgetRadio) budgetRadio.checked = true;
    }

    // Set Vibe
    if (data.vibe) {
        const vibeRadio = document.querySelector(`input[name="vibe"][value="${data.vibe.toLowerCase()}"]`);
        if (vibeRadio) vibeRadio.checked = true;
    }

    // Trigger Generation
    generateItinerary();
}

function addTypingIndicator() {
    const container = document.getElementById('chat-messages');
    const id = 'typing-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'flex items-start gap-3';
    div.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-robot text-brand-600 text-sm"></i>
        </div>
        <div class="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-100">
            <div class="flex gap-1">
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
            </div>
        </div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return id;
}

function removeTypingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
}

// Itinerary Modification Functions
let currentItineraryData = null;

function showModificationPrompt() {
    const prompt = document.getElementById('modification-prompt');
    const input = document.getElementById('modification-input');
    prompt.classList.remove('hidden');
    input.focus();
}

function hideModificationPrompt() {
    const prompt = document.getElementById('modification-prompt');
    const input = document.getElementById('modification-input');
    prompt.classList.add('hidden');
    input.value = '';
}

async function applyModifications() {
    const input = document.getElementById('modification-input');
    const modificationRequest = input.value.trim();

    if (!modificationRequest) {
        alert('Please describe what changes you would like to make.');
        return;
    }

    if (!currentItineraryData) {
        alert('No itinerary data available. Please generate a new itinerary.');
        return;
    }

    // Show loading state
    const prompt = document.getElementById('modification-prompt');
    prompt.innerHTML = `
        <div class="flex items-center gap-3 text-brand-700">
            <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-brand-600"></div>
            <span class="text-sm font-medium">Applying your changes...</span>
        </div>
    `;

    try {
        // Send modification request to backend
        const response = await fetch('/api/modify-itinerary', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                current_itinerary: currentItineraryData,
                modification_request: modificationRequest
            })
        });

        if (!response.ok) throw new Error('Modification failed');

        const updatedData = await response.json();

        // Store updated data and re-render
        currentItineraryData = updatedData;
        renderItinerary(updatedData);

    } catch (error) {
        console.error('Modification Error:', error);

        // Restore prompt on error
        hideModificationPrompt();
        alert('Failed to apply modifications. Please try again or describe your changes differently.');
    }
}
