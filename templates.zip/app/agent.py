import os
import json
import random
from typing import Dict, List, Any
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

# Configure API Key
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)

def get_chat_response(message: str, history: List[Dict[str, Any]] = None) -> str:
    """
    Context-aware chat agent for travel planning with conversation memory.
    """
    if not GOOGLE_API_KEY:
        return "I'm in offline mode, but I'd love to help you plan a trip! (API Key missing)"
    
    if history is None:
        history = []
    
    # Using gemini-flash-latest
    model = genai.GenerativeModel('gemini-flash-latest')
    
    # Build conversation context
    conversation_context = ""
    if history:
        # Get last 10 messages for context (5 exchanges)
        recent_history = history[-10:] if len(history) > 10 else history
        for msg in recent_history:
            role = "User" if msg.get('role') == 'user' else "Travello"
            conversation_context += f"{role}: {msg.get('content', '')}\n"
    
    prompt = f"""
    You are an enthusiastic and helpful travel agent named Travello.
    You maintain context from previous messages in the conversation.
    
    CONVERSATION HISTORY:
    {conversation_context}
    
    USER'S CURRENT MESSAGE: "{message}"
    
    INSTRUCTIONS:
    - Remember what the user has told you (destination, source, budget, preferences, etc.)
    - Build on previous context.
    - CRITICAL: You MUST extract the "source" (starting location). If the user hasn't provided it, you MUST ask: "Where will you be traveling from?"
    - Do NOT set "ready": true unless you have BOTH "destination" AND "source".
    - If the user says "Plan My Trip Now" but you don't have the source, ask for the source instead of planning.
    
    OUTPUT FORMAT:
    You must return a JSON object with the following structure:
    {{
        "text": "Your conversational response here...",
        "plan_trip": {{
            "destination": "extracted destination or null",
            "source": "extracted source city or null",
            "days": 3, // integer, default to 3 if unknown
            "budget": "moderate", // budget, moderate, or luxury
            "vibe": "tourist", // tourist or local
            "ready": boolean // true ONLY if Destination AND Source are known
        }}
    }}
    
    Example Response:
    {{
        "text": "That sounds perfect! I've set up a 5-day trip to Paris for you. Click the button below to see your itinerary!",
        "plan_trip": {{
            "destination": "Paris",
            "source": "London",
            "days": 5,
            "budget": "moderate",
            "vibe": "tourist",
            "ready": true
        }}
    }}
    
    Ensure the response is valid JSON. Do not include markdown formatting like ```json.
    """
    
    try:
        response = model.generate_content(prompt)
        cleaned_response = response.text.replace('```json', '').replace('```', '').strip()
        return cleaned_response
    except Exception as e:
        print(f"Chat error: {str(e)}")
        # Fallback JSON
        return '{"text": "I\'m having a bit of trouble connecting. Please try again.", "plan_trip": {"ready": false}}'

def generate_itinerary_agent(source: str, destination: str, days: int, budget: str, vibe: str, interests: List[str]) -> Dict[str, Any]:
    """
    Generates a travel itinerary.
    Tries to use Gemini Pro. If fails (no key or error), falls back to mock data.
    """

    print(f"Generating itinerary from {source} to {destination}, {days} days, {budget} budget, {vibe} vibe, {interests}")
    
    if GOOGLE_API_KEY:
        print("Google API Key found. Attempting to use Gemini...")
        try:
            return _generate_with_gemini(source, destination, days, budget, vibe, interests)
        except Exception as e:
            error_msg = f"Gemini generation failed: {str(e)}"
            print(error_msg)
            # Write to log file for debugging
            with open("error_log.txt", "w") as f:
                f.write(error_msg)
                import traceback
                traceback.print_exc(file=f)
            
            print("Falling back to mock data.")
            return _generate_mock(source, destination, days, budget, interests)
    else:
        print("No Google API Key found. Using mock generator.")
        return _generate_mock(source, destination, days, budget, interests)

def _generate_with_gemini(source: str, destination: str, days: int, budget: str, vibe: str, interests: List[str]) -> Dict[str, Any]:
    # Using gemini-flash-latest as it is explicitly available for this key
    model = genai.GenerativeModel('gemini-flash-latest')
    
    vibe_desc = "Focus on popular tourist landmarks and must-see spots."
    if vibe == "local":
        vibe_desc = "Focus on hidden gems, local favorites, and off-the-beaten-path experiences. Avoid tourist traps."

    prompt = f"""
    Act as an expert travel agent. Create a detailed {days}-day itinerary for a trip from {source} to {destination}.
    
    User Preferences:
    - Budget: {budget}
    - Travel Vibe: {vibe_desc}
    - Interests: {', '.join(interests)}
    
    Output MUST be valid JSON with the following structure:
    {{
        "source": "{source}",
        "source_lat": 28.6139,
        "source_lng": 77.2090,
        "destination": "{destination}",
        "destination_lat": 34.0837,
        "destination_lng": 74.7973,
        "trip_essentials": {{
            "packing_list": ["Item 1", "Item 2", "Item 3"],
            "safety_tips": ["Emergency Number: 112", "Avoid X area at night"],
            "cultural_norms": ["Do Y", "Don't Z"],
            "weather_info": "Expected weather summary"
        }},
        "days": [
            {{
                "day": 1,
                "theme": "Theme of the day",
                "activities": [
                    {{
                        "time": "09:00 AM",
                        "title": "Activity Name",
                        "description": "Brief description",
                        "type": "culture|food|shopping|sightseeing|art|nature",
                        "rainy_day_alternative": "Name of an indoor alternative activity if the main one is outdoors (or 'N/A')",
                        "lat": 35.6762, 
                        "lng": 139.6503
                    }}
                ]
            }}
        ]
    }}
    
    IMPORTANT:
    1. Provide REAL coordinates (latitude and longitude) for the Source, Destination, and each activity. Do not use 0.0.
    2. If you don't know the exact coordinates, approximate them based on the city center.
    3. Return ONLY the JSON. No markdown formatting like ```json.
    """
    
    response = model.generate_content(prompt)
    text = response.text
    print(f"Raw AI Response: {text[:200]}...") # Log first 200 chars
    
    # Clean up markdown code blocks if present
    if text.startswith("```json"):
        text = text[7:]
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
        
    return json.loads(text)

def _generate_mock(source: str, destination: str, days: int, budget: str, interests: List[str]) -> Dict[str, Any]:
    """
    Sophisticated mock generator that creates a believable itinerary structure.
    """
    themes = ["City Exploration", "Cultural Deep Dive", "Culinary Journey", "Nature & Relaxation", "Hidden Gems"]
    activity_types = ["culture", "food", "shopping", "sightseeing", "art", "nature"]
    
    mock_days = []
    
    # Base coordinates for a few popular cities to make the map look okay-ish
    # If unknown, defaults to 0,0 (user will see ocean, which is fine for a fallback)
    base_coords = {
        "tokyo": (35.6762, 139.6503),
        "paris": (48.8566, 2.3522),
        "new york": (40.7128, -74.0060),
        "london": (51.5074, -0.1278),
        "dubai": (25.2048, 55.2708),
        "delhi": (28.6139, 77.2090),
        "mumbai": (19.0760, 72.8777),
        "kashmir": (34.0837, 74.7973)
    }
    
    dest_lower = destination.lower()
    source_lower = source.lower()
    
    start_lat, start_lng = (0, 0)
    source_lat, source_lng = (0, 0)
    
    for key, val in base_coords.items():
        if key in dest_lower:
            start_lat, start_lng = val
        if key in source_lower:
            source_lat, source_lng = val
            
    for i in range(1, days + 1):
        day_activities = []
        num_activities = random.randint(3, 5)
        
        for j in range(num_activities):
            act_type = random.choice(activity_types)
            # Add small random offset to coordinates to scatter them on map
            lat_offset = random.uniform(-0.05, 0.05)
            lng_offset = random.uniform(-0.05, 0.05)
            
            day_activities.append({
                "time": f"{9 + j*3}:00 {'AM' if 9 + j*3 < 12 else 'PM'}",
                "title": f"Explore {destination} {act_type.title()} Spot #{j+1}",
                "description": f"A wonderful {budget} experience focusing on {random.choice(interests) if interests else 'fun'}.",
                "type": act_type,
                "rainy_day_alternative": "Visit the local museum",
                "lat": start_lat + lat_offset if start_lat != 0 else 0,
                "lng": start_lng + lng_offset if start_lng != 0 else 0
            })
            
        mock_days.append({
            "day": i,
            "theme": random.choice(themes),
            "activities": day_activities
        })
        
    return {
        "source": source,
        "source_lat": source_lat,
        "source_lng": source_lng,
        "destination": destination,
        "destination_lat": start_lat,
        "destination_lng": start_lng,
        "trip_essentials": {
            "packing_list": ["Comfortable walking shoes", "Universal power adapter", "Light jacket", "Camera"],
            "safety_tips": ["Keep valuables secure", "Use official taxis only", "Emergency number is 112"],
            "cultural_norms": ["Greet with a smile", "Tip 10-15% at restaurants"],
            "weather_info": "Expect sunny days with cool evenings."
        },
        "days": mock_days
    }

def modify_itinerary_with_ai(current_itinerary: Dict[str, Any], modification_request: str) -> Dict[str, Any]:
    """
    Modifies an existing itinerary based on user's natural language request.
    """
    if not GOOGLE_API_KEY:
        # If no API key, return current itinerary with a note
        return current_itinerary
    
    try:
        model = genai.GenerativeModel('gemini-flash-latest')
        
        # Create a detailed prompt for modification
        prompt = f"""
        You are a travel itinerary modification expert. The user has an existing itinerary and wants to make changes.
        
        CURRENT ITINERARY:
        {json.dumps(current_itinerary, indent=2)}
        
        USER'S MODIFICATION REQUEST:
        "{modification_request}"
        
        Please modify the itinerary according to the user's request. Maintain the same JSON structure.
        
        IMPORTANT RULES:
        1. Keep the same overall structure (source, destination, coordinates, trip_essentials, days array)
        2. Only modify what the user specifically requests
        3. If they ask to change activities, update the activities array for the relevant days
        4. If they ask for different types of experiences, adjust the activity types and descriptions
        5. If they mention budget changes, adjust recommendations accordingly
        6. Maintain real coordinates for all locations
        7. Keep the trip_essentials updated if the changes affect packing, safety, or cultural norms
        8. Return ONLY valid JSON, no markdown formatting
        
        Return the complete modified itinerary as JSON.
        """
        
        response = model.generate_content(prompt)
        text = response.text
        
        # Clean up markdown code blocks if present
        if text.startswith("```json"):
            text = text[7:]
        if text.startswith("```"):
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        
        modified_itinerary = json.loads(text.strip())
        return modified_itinerary
        
    except Exception as e:
        print(f"Modification error: {str(e)}")
        # Return original itinerary if modification fails
        return current_itinerary

