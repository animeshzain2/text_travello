from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List, Optional
import uvicorn
import os
try:
    from app.agent import generate_itinerary_agent
except ImportError:
    from agent import generate_itinerary_agent

app = FastAPI(title="Travello AI Agent")

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup templates
templates = Jinja2Templates(directory="templates")

class PreferenceRequest(BaseModel):
    source: str
    destination: str
    days: int
    budget: str
    vibe: str = "tourist" # Default to tourist
    interests: List[str]

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

class ChatRequest(BaseModel):
    message: str
    history: List[dict] = []

@app.post("/api/chat")
async def chat_agent(request: ChatRequest):
    try:
        from app.agent import get_chat_response
        response = get_chat_response(request.message, request.history)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/generate")
async def generate_itinerary(prefs: PreferenceRequest):
    try:
        itinerary = generate_itinerary_agent(
            source=prefs.source,
            destination=prefs.destination,
            days=prefs.days,
            budget=prefs.budget,
            vibe=prefs.vibe,
            interests=prefs.interests
        )
        return itinerary
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def health_check():
    return {"status": "ok", "message": "Travello API is running"}

class ModificationRequest(BaseModel):
    current_itinerary: dict
    modification_request: str

@app.post("/api/modify-itinerary")
async def modify_itinerary(request: ModificationRequest):
    try:
        from app.agent import modify_itinerary_with_ai
        modified_itinerary = modify_itinerary_with_ai(
            current_itinerary=request.current_itinerary,
            modification_request=request.modification_request
        )
        return modified_itinerary
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
