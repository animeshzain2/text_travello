
import os

file_path = 'd:/Travello/static/js/app.js'

# The new chat logic to append
chat_logic = r'''
// Chat Interface Logic
function startChat() {
    document.getElementById('chat-container').classList.remove('hidden');
    document.getElementById('chat-input').focus();
}

function closeChat() {
    document.getElementById('chat-container').classList.add('hidden');
    // Clear chat history when closing
    chatHistory = [];
}

// Chat history storage
let chatHistory = [];

async function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (!message) return;

    // Add User Message to UI
    addMessageToChat(message, 'user');
    input.value = '';

    // Show Typing Indicator
    const typingId = addTypingIndicator();

    try {
        // Send request with history BEFORE adding current message
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                message: message,
                history: chatHistory
            })
        });

        if (!response.ok) throw new Error('Chat failed');

        const data = await response.json();

        // Parse the response
        let aiResponseText = data.response;
        let planTripData = null;

        try {
            // Try to parse if it's a JSON string
            if (typeof data.response === 'string' && (data.response.startsWith('{') || data.response.startsWith('['))) {
                 const parsedResponse = JSON.parse(data.response);
                 if (parsedResponse.text) {
                     aiResponseText = parsedResponse.text;
                 }
                 if (parsedResponse.plan_trip && parsedResponse.plan_trip.ready) {
                     planTripData = parsedResponse.plan_trip;
                 }
            }
        } catch (e) {
            console.log("Response parsing error:", e);
        }

        removeTypingIndicator(typingId);
        
        // Add AI response to UI
        addMessageToChat(aiResponseText, 'ai');
        
        // If ready to plan, add the button
        if (planTripData) {
            addPlanTripButton(planTripData);
        }
        
        // Add to history AFTER successful send
        chatHistory.push({
            role: 'user',
            content: message
        });
        
        // Add AI response to history
        chatHistory.push({
            role: 'assistant',
            content: aiResponseText
        });

    } catch (error) {
        console.error('Chat Error:', error);
        removeTypingIndicator(typingId);
        addMessageToChat("Sorry, I'm having trouble connecting right now.", 'ai');
    }
}

function addMessageToChat(text, sender) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`;

    const avatar = sender === 'ai'
        ? `<div class="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0"><i class="fas fa-robot text-brand-600 text-sm"></i></div>`
        : `<div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0"><i class="fas fa-user text-blue-600 text-sm"></i></div>`;

    const bubbleClass = sender === 'ai'
        ? 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
        : 'bg-brand-600 text-white rounded-tr-none shadow-md shadow-brand-500/20';

    div.innerHTML = `
        ${sender === 'ai' ? avatar : ''}
        <div class="${bubbleClass} p-4 rounded-2xl shadow-sm max-w-[80%] ${sender === 'ai' ? 'ml-3' : 'mr-3'}">
            <p>${text}</p>
        </div>
        ${sender === 'user' ? avatar : ''}
    `;

    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function addPlanTripButton(planData) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = 'flex justify-start pl-11 mb-4'; // Indent to align with AI bubble
    
    // Store data in a way we can access it
    const dataString = JSON.stringify(planData).replace(/"/g, '&quot;');
    
    div.innerHTML = `
        <button onclick="triggerPlanTrip(${dataString})" 
            class="bg-brand-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-brand-500/30 hover:bg-brand-700 transition-all transform hover:scale-105 flex items-center gap-2">
            <span>✨ Plan My Trip Now</span>
            <i class="fas fa-arrow-right"></i>
        </button>
    `;
    
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function triggerPlanTrip(data) {
    // Close chat
    closeChat();
    
    // Populate Form
    if (data.source) document.getElementById('source').value = data.source;
    if (data.destination) document.getElementById('destination').value = data.destination;
    
    // Set Duration
    if (data.days) {
        selectDuration(data.days);
    }
    
    // Set Budget
    if (data.budget) {
        const budgetRadio = document.querySelector(`input[name="budget"][value="${data.budget.toLowerCase()}"]`);
        if (budgetRadio) budgetRadio.checked = true;
    }
    
    // Set Vibe
    if (data.vibe) {
        const vibeRadio = document.querySelector(`input[name="vibe"][value="${data.vibe.toLowerCase()}"]`);
        if (vibeRadio) vibeRadio.checked = true;
    }
    
    // Trigger Generation
    generateItinerary();
}

function addTypingIndicator() {
    const container = document.getElementById('chat-messages');
    const id = 'typing-' + Date.now();
    const div = document.createElement('div');
    div.id = id;
    div.className = 'flex items-start gap-3';
    div.innerHTML = `
        <div class="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center flex-shrink-0">
            <i class="fas fa-robot text-brand-600 text-sm"></i>
        </div>
        <div class="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-100">
            <div class="flex gap-1">
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
            </div>
        </div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
    return id;
}

function removeTypingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
}

// Itinerary Modification Functions
let currentItineraryData = null;

function showModificationPrompt() {
    const prompt = document.getElementById('modification-prompt');
    const input = document.getElementById('modification-input');
    prompt.classList.remove('hidden');
    input.focus();
}

function hideModificationPrompt() {
    const prompt = document.getElementById('modification-prompt');
    const input = document.getElementById('modification-input');
    prompt.classList.add('hidden');
    input.value = '';
}

async function applyModifications() {
    const input = document.getElementById('modification-input');
    const modificationRequest = input.value.trim();

    if (!modificationRequest) {
        alert('Please describe what changes you would like to make.');
        return;
    }

    if (!currentItineraryData) {
        alert('No itinerary data available. Please generate a new itinerary.');
        return;
    }

    // Show loading state
    const prompt = document.getElementById('modification-prompt');
    prompt.innerHTML = `
        <div class="flex items-center gap-3 text-brand-700">
            <div class="animate-spin rounded-full h-5 w-5 border-b-2 border-brand-600"></div>
            <span class="text-sm font-medium">Applying your changes...</span>
        </div>
    `;

    try {
        // Send modification request to backend
        const response = await fetch('/api/modify-itinerary', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                current_itinerary: currentItineraryData,
                modification_request: modificationRequest
            })
        });

        if (!response.ok) throw new Error('Modification failed');

        const updatedData = await response.json();

        // Store updated data and re-render
        currentItineraryData = updatedData;
        renderItinerary(updatedData);

    } catch (error) {
        console.error('Modification Error:', error);

        // Restore prompt on error
        hideModificationPrompt();
        alert('Failed to apply modifications. Please try again or describe your changes differently.');
    }
}
'''

with open(file_path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Keep lines 1-484 (0-indexed: 0-483)
# Line 484 in 1-indexed is index 483.
# We want to keep up to index 483 inclusive?
# Line 484 was `// Chat Interface Logic` in the original file?
# No, line 485 was `function startChat()`.
# So we want to keep lines before that.
# Let's verify line 483 and 484.
# In previous view:
# 482: }
# 483: 
# 484: // Chat Interface Logic
# 485: function startChat() {

# So we want to keep up to line 482 (index 481).
# And maybe the empty line 483 (index 482).
# And then append our new logic.

new_content = "".join(lines[:483]) + "\n" + chat_logic

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Successfully updated app.js")
