# Travello - AI Itinerary Planner

Travello is an intelligent, AI-powered travel itinerary generator built with FastAPI and Google Gemini. It creates personalized day-by-day trip plans with interactive maps, budget estimates, and smart contingency planning.

## 🚀 Features

- **AI-Powered Planning**: Generates detailed itineraries based on destination, budget, vibe, and interests.
- **Interactive Maps**: Visualizes routes and activities using Leaflet.js.
- **Smart Contingencies**: Automatically suggests indoor alternatives for rainy days.
- **Trip Essentials**: Provides packing lists and safety tips.
- **AI Chat Assistant**: Integrated chat for travel advice and itinerary refinement.
- **Print Friendly**: Export professional-looking itineraries to PDF.

## 🛠️ Prerequisites

Before running the project, ensure you have the following installed:

- **Python 3.8+**: [Download Python](https://www.python.org/downloads/)
- **Git** (Optional, for cloning): [Download Git](https://git-scm.com/downloads)

## 📦 Installation & Setup

Follow these steps to set up the project on a new machine:

### 1. Get the Code
Copy the `Travello` folder to your new laptop or clone the repository if you have one.

### 2. Create a Virtual Environment
Open your terminal or command prompt, navigate to the project folder, and run:

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
Install the required Python packages:

```bash
pip install -r requirements.txt
```

*Note: If you don't have a `requirements.txt` file yet, create one with the following content:*
```text
fastapi
uvicorn
jinja2
python-dotenv
google-generativeai
pydantic
```

### 4. Set Up Environment Variables
Create a file named `.env` in the root directory (same level as `app/` and `static/`) and add your Google Gemini API key:

```env
GOOGLE_API_KEY=your_actual_api_key_here
```

*You can get a free API key from [Google AI Studio](https://aistudio.google.com/app/apikey).*

## ▶️ Running the Application

To start the server, run:

```bash
uvicorn app.main:app --reload
```

Once the server is running, open your browser and go to:
**http://127.0.0.1:8000**

## ❓ Troubleshooting

- **"Module not found"**: Ensure you activated your virtual environment (`venv\Scripts\activate`) before running the server.
- **API Errors**: Check if your `GOOGLE_API_KEY` in the `.env` file is correct and has active quota.
- **Port already in use**: If port 8000 is busy, run on a different port: `uvicorn app.main:app --reload --port 8001`
